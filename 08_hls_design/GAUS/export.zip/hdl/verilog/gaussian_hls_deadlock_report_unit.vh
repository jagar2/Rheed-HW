   
    parameter PROC_NUM = 27;
    parameter ST_IDLE = 3'b000;
    parameter ST_FILTER_FAKE = 3'b001;
    parameter ST_DL_DETECTED = 3'b010;
    parameter ST_DL_REPORT = 3'b100;
   

    reg [2:0] CS_fsm;
    reg [2:0] NS_fsm;
    reg [PROC_NUM - 1:0] dl_detect_reg;
    reg [PROC_NUM - 1:0] dl_done_reg;
    reg [PROC_NUM - 1:0] origin_reg;
    reg [PROC_NUM - 1:0] dl_in_vec_reg;
    reg [31:0] dl_keep_cnt;
    reg stop_report_path;
    reg [PROC_NUM - 1:0] reported_proc;
    integer i;
    integer fp;

    always @ (negedge dl_reset or posedge dl_clock) begin
        if (~dl_reset) begin
            reported_proc <= 'b0;
        end
        else if (CS_fsm == ST_DL_REPORT) begin
            reported_proc <= reported_proc | dl_in_vec;
        end
        else if (CS_fsm == ST_DL_DETECTED) begin
            reported_proc <= 'b0;
        end
    end

    always @ (negedge dl_reset or posedge dl_clock) begin
        if (~dl_reset) begin
            stop_report_path <= 1'b0;
        end
        else if (CS_fsm == ST_DL_REPORT && (|(dl_in_vec & reported_proc))) begin
            stop_report_path <= 1'b1;
        end
        else if (CS_fsm == ST_IDLE) begin
            stop_report_path <= 1'b0;
        end
    end

    // FSM State machine
    always @ (negedge dl_reset or posedge dl_clock) begin
        if (~dl_reset) begin
            CS_fsm <= ST_IDLE;
        end
        else begin
            CS_fsm <= NS_fsm;
        end
    end

    always @ (CS_fsm or dl_in_vec or dl_detect_reg or dl_done_reg or dl_in_vec or origin_reg or dl_keep_cnt) begin
        case (CS_fsm)
            ST_IDLE : begin
                if (|dl_in_vec) begin
                    NS_fsm = ST_FILTER_FAKE;
                end
                else begin
                    NS_fsm = ST_IDLE;
                end
            end
            ST_FILTER_FAKE: begin
                if (dl_keep_cnt >= 32'd1000) begin
                    NS_fsm = ST_DL_DETECTED;
                end
                else if (dl_detect_reg != (dl_detect_reg & dl_in_vec)) begin
                    NS_fsm = ST_IDLE;
                end
                else begin
                    NS_fsm = ST_FILTER_FAKE;
                end
            end
            ST_DL_DETECTED: begin
                // has unreported deadlock cycle
                if ((dl_detect_reg != dl_done_reg) && stop_report_path == 1'b0) begin
                    NS_fsm = ST_DL_REPORT;
                end
                else begin
                    NS_fsm = ST_DL_DETECTED;
                end
            end
            ST_DL_REPORT: begin
                if (|(dl_in_vec & origin_reg)) begin
                    NS_fsm = ST_DL_DETECTED;
                end
                // avoid report deadlock ring.
                else if (|(dl_in_vec & reported_proc)) begin
                    NS_fsm = ST_DL_DETECTED;
                end
                else begin
                    NS_fsm = ST_DL_REPORT;
                end
            end
            default: NS_fsm = ST_IDLE;
        endcase
    end

    // dl_detect_reg record the procs that first detect deadlock
    always @ (negedge dl_reset or posedge dl_clock) begin
        if (~dl_reset) begin
            dl_detect_reg <= 'b0;
        end
        else begin
            if (CS_fsm == ST_IDLE) begin
                dl_detect_reg <= dl_in_vec;
            end
        end
    end

    always @ (negedge dl_reset or posedge dl_clock) begin
        if (~dl_reset) begin
            dl_keep_cnt <= 32'h0;
        end
        else begin
            if (CS_fsm == ST_FILTER_FAKE && (dl_detect_reg == (dl_detect_reg & dl_in_vec))) begin
                dl_keep_cnt <= dl_keep_cnt + 32'h1;
            end
            else if (CS_fsm == ST_FILTER_FAKE && (dl_detect_reg != (dl_detect_reg & dl_in_vec))) begin
                dl_keep_cnt <= 32'h0;
            end
        end
    end

    // dl_detect_out keeps in high after deadlock detected
    assign dl_detect_out = (|dl_detect_reg) && (CS_fsm == ST_DL_DETECTED || CS_fsm == ST_DL_REPORT);

    // dl_done_reg record the cycles has been reported
    always @ (negedge dl_reset or posedge dl_clock) begin
        if (~dl_reset) begin
            dl_done_reg <= 'b0;
        end
        else begin
            if ((CS_fsm == ST_DL_REPORT) && (|(dl_in_vec & dl_detect_reg) == 'b1)) begin
                dl_done_reg <= dl_done_reg | dl_in_vec;
            end
        end
    end

    // clear token once a cycle is done
    assign token_clear = (CS_fsm == ST_DL_REPORT) ? ((|(dl_in_vec & origin_reg)) ? 'b1 : 'b0) : 'b0;

    // origin_reg record the current cycle start id
    always @ (negedge dl_reset or posedge dl_clock) begin
        if (~dl_reset) begin
            origin_reg <= 'b0;
        end
        else begin
            if (CS_fsm == ST_DL_DETECTED) begin
                origin_reg <= origin;
            end
        end
    end
   
    // origin will be valid for only one cycle
    wire [PROC_NUM*PROC_NUM - 1:0] origin_tmp;
    assign origin_tmp[PROC_NUM - 1:0] = (dl_detect_reg[0] & ~dl_done_reg[0]) ? 'b1 : 'b0;
    genvar j;
    generate
    for(j = 1;j < PROC_NUM;j = j + 1) begin: F1
        assign origin_tmp[j*PROC_NUM +: PROC_NUM] = (dl_detect_reg[j] & ~dl_done_reg[j]) ? ('b1 << j) : origin_tmp[(j - 1)*PROC_NUM +: PROC_NUM];
    end
    endgenerate
    always @ (CS_fsm or origin_tmp) begin
        if (CS_fsm == ST_DL_DETECTED) begin
            origin = origin_tmp[(PROC_NUM - 1)*PROC_NUM +: PROC_NUM];
        end
        else begin
            origin = 'b0;
        end
    end

    
    // dl_in_vec_reg record the current cycle dl_in_vec
    always @ (negedge dl_reset or posedge dl_clock) begin
        if (~dl_reset) begin
            dl_in_vec_reg <= 'b0;
        end
        else begin
            if (CS_fsm == ST_DL_DETECTED) begin
                dl_in_vec_reg <= origin;
            end
            else if (CS_fsm == ST_DL_REPORT) begin
                dl_in_vec_reg <= dl_in_vec;
            end
        end
    end
    
    // find_df_deadlock to report the deadlock
    always @ (negedge dl_reset or posedge dl_clock) begin
        if (~dl_reset) begin
            find_df_deadlock <= 1'b0;
        end
        else begin
            if (CS_fsm == ST_DL_DETECTED && ((dl_detect_reg == dl_done_reg) || (stop_report_path == 1'b1))) begin
                find_df_deadlock <= 1'b1;
            end
            else if (CS_fsm == ST_IDLE) begin
                find_df_deadlock <= 1'b0;
            end
        end
    end
    
    // get the first valid proc index in dl vector
    function integer proc_index(input [PROC_NUM - 1:0] dl_vec);
        begin
            proc_index = 0;
            for (i = 0; i < PROC_NUM; i = i + 1) begin
                if (dl_vec[i]) begin
                    proc_index = i;
                end
            end
        end
    endfunction

    // get the proc path based on dl vector
    function [752:0] proc_path(input [PROC_NUM - 1:0] dl_vec);
        integer index;
        begin
            index = proc_index(dl_vec);
            case (index)
                0 : begin
                    proc_path = "gaussian_gaussian.zeropad2d_cl_array_ap_fixed_1u_array_ap_fixed_16_6_5_3_0_1u_config34_U0";
                end
                1 : begin
                    proc_path = "gaussian_gaussian.conv_2d_cl_array_ap_fixed_1u_array_ap_fixed_29_12_5_3_0_6u_config2_U0";
                end
                2 : begin
                    proc_path = "gaussian_gaussian.relu_array_ap_fixed_6u_array_ap_ufixed_8_0_4_0_0_6u_relu_config4_U0";
                end
                3 : begin
                    proc_path = "gaussian_gaussian.pooling2d_cl_array_ap_ufixed_6u_array_ap_ufixed_8_0_4_0_0_6u_config5_U0";
                end
                4 : begin
                    proc_path = "gaussian_gaussian.zeropad2d_cl_array_array_ap_ufixed_8_0_4_0_0_6u_config35_U0";
                end
                5 : begin
                    proc_path = "gaussian_gaussian.conv_2d_cl_array_ap_ufixed_6u_array_ap_fixed_23_8_5_3_0_8u_config6_U0";
                end
                6 : begin
                    proc_path = "gaussian_gaussian.relu_array_ap_fixed_8u_array_ap_ufixed_8_0_4_0_0_8u_relu_config8_U0";
                end
                7 : begin
                    proc_path = "gaussian_gaussian.pooling2d_cl_array_ap_ufixed_8u_array_ap_ufixed_8_0_4_0_0_8u_config9_U0";
                end
                8 : begin
                    proc_path = "gaussian_gaussian.zeropad2d_cl_array_array_ap_ufixed_8_0_4_0_0_8u_config36_U0";
                end
                9 : begin
                    proc_path = "gaussian_gaussian.conv_2d_cl_array_ap_ufixed_8u_array_ap_fixed_24_9_5_3_0_8u_config10_U0";
                end
                10 : begin
                    proc_path = "gaussian_gaussian.relu_array_ap_fixed_8u_array_ap_ufixed_8_0_4_0_0_8u_relu_config12_U0";
                end
                11 : begin
                    proc_path = "gaussian_gaussian.pooling2d_cl_array_array_ap_ufixed_8_0_4_0_0_8u_config13_U0";
                end
                12 : begin
                    proc_path = "gaussian_gaussian.global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config14_U0";
                end
                13 : begin
                    proc_path = "gaussian_gaussian.dense_array_ap_fixed_8u_array_ap_fixed_28_11_5_3_0_16u_config15_U0";
                end
                14 : begin
                    proc_path = "gaussian_gaussian.relu_array_ap_fixed_16u_array_ap_ufixed_8_0_4_0_0_16u_relu_config17_U0";
                end
                15 : begin
                    proc_path = "gaussian_gaussian.clone_stream_array_ap_ufixed_16u_array_ap_ufixed_8_0_4_0_0_16u_16_U0";
                end
                16 : begin
                    proc_path = "gaussian_gaussian.dense_array_ap_ufixed_16u_array_ap_fixed_29_11_5_3_0_2u_config18_U0";
                end
                17 : begin
                    proc_path = "gaussian_gaussian.dense_array_ap_ufixed_16u_array_ap_fixed_29_11_5_3_0_2u_config20_U0";
                end
                18 : begin
                    proc_path = "gaussian_gaussian.dense_array_ap_ufixed_16u_array_ap_fixed_29_11_5_3_0_2u_config22_U0";
                end
                19 : begin
                    proc_path = "gaussian_gaussian.dense_array_ap_ufixed_16u_array_ap_fixed_29_11_5_3_0_1u_config24_U0";
                end
                20 : begin
                    proc_path = "gaussian_gaussian.sigmoid_array_array_ap_fixed_16_6_5_3_0_2u_sigmoid_config26_U0";
                end
                21 : begin
                    proc_path = "gaussian_gaussian.softplus_array_array_ap_fixed_16_6_5_3_0_2u_softplus_config27_U0";
                end
                22 : begin
                    proc_path = "gaussian_gaussian.tanh_array_ap_fixed_2u_array_ap_fixed_16_6_5_3_0_2u_tanh_config28_U0";
                end
                23 : begin
                    proc_path = "gaussian_gaussian.sigmoid_array_array_ap_fixed_16_6_5_3_0_1u_sigmoid_config29_U0";
                end
                24 : begin
                    proc_path = "gaussian_gaussian.concatenate1d_array_array_array_ap_fixed_16_6_5_3_0_4u_config30_U0";
                end
                25 : begin
                    proc_path = "gaussian_gaussian.concatenate1d_array_array_array_ap_fixed_16_6_5_3_0_3u_config31_U0";
                end
                26 : begin
                    proc_path = "gaussian_gaussian.concatenate1d_array_array_array_ap_fixed_16_6_5_3_0_7u_config32_U0";
                end
                default : begin
                    proc_path = "unknown";
                end
            endcase
        end
    endfunction

    // print the headlines of deadlock detection
    task print_dl_head;
        begin
            $display("\n//////////////////////////////////////////////////////////////////////////////");
            $display("// ERROR!!! DEADLOCK DETECTED at %0t ns! SIMULATION WILL BE STOPPED! //", $time);
            $display("//////////////////////////////////////////////////////////////////////////////");
            fp = $fopen("deadlock_db.dat", "w");
        end
    endtask

    // print the start of a cycle
    task print_cycle_start(input reg [752:0] proc_path, input integer cycle_id);
        begin
            $display("/////////////////////////");
            $display("// Dependence cycle %0d:", cycle_id);
            $display("// (1): Process: %0s", proc_path);
            $fdisplay(fp, "Dependence_Cycle_ID %0d", cycle_id);
            $fdisplay(fp, "Dependence_Process_ID 1");
            $fdisplay(fp, "Dependence_Process_path %0s", proc_path);
        end
    endtask

    // print the end of deadlock detection
    task print_dl_end(input integer num, input integer record_time);
        begin
            $display("////////////////////////////////////////////////////////////////////////");
            $display("// Totally %0d cycles detected!", num);
            $display("////////////////////////////////////////////////////////////////////////");
            $display("// ERROR!!! DEADLOCK DETECTED at %0t ns! SIMULATION WILL BE STOPPED! //", record_time);
            $display("//////////////////////////////////////////////////////////////////////////////");
            $fdisplay(fp, "Dependence_Cycle_Number %0d", num);
            $fclose(fp);
        end
    endtask

    // print one proc component in the cycle
    task print_cycle_proc_comp(input reg [752:0] proc_path, input integer cycle_comp_id);
        begin
            $display("// (%0d): Process: %0s", cycle_comp_id, proc_path);
            $fdisplay(fp, "Dependence_Process_ID %0d", cycle_comp_id);
            $fdisplay(fp, "Dependence_Process_path %0s", proc_path);
        end
    endtask

    // print one channel component in the cycle
    task print_cycle_chan_comp(input [PROC_NUM - 1:0] dl_vec1, input [PROC_NUM - 1:0] dl_vec2);
        reg [840:0] chan_path;
        integer index1;
        integer index2;
        begin
            index1 = proc_index(dl_vec1);
            index2 = proc_index(dl_vec2);
            case (index1)
                0 : begin // for proc 'gaussian_gaussian.zeropad2d_cl_array_ap_fixed_1u_array_ap_fixed_16_6_5_3_0_1u_config34_U0'
                    case(index2)
                    1: begin //  for dep proc 'gaussian_gaussian.conv_2d_cl_array_ap_fixed_1u_array_ap_fixed_29_12_5_3_0_6u_config2_U0'
// for dep channel 'gaussian_gaussian.layer34_out_U' info is :
// blk sig is {~gaussian_gaussian_inst.zeropad2d_cl_array_ap_fixed_1u_array_ap_fixed_16_6_5_3_0_1u_config34_U0.grp_zeropad2d_cl_array_array_ap_fixed_16_6_5_3_0_1u_config34_Pipeline_PadTopWidth_fu_28.layer34_out_blk_n data_FIFO}
                        if ((~zeropad2d_cl_array_ap_fixed_1u_array_ap_fixed_16_6_5_3_0_1u_config34_U0.grp_zeropad2d_cl_array_array_ap_fixed_16_6_5_3_0_1u_config34_Pipeline_PadTopWidth_fu_28.layer34_out_blk_n)) begin
                            if (~layer34_out_U.if_empty_n) begin
                                $display("//      Blocked by empty input FIFO 'gaussian_gaussian.layer34_out_U' written by process 'gaussian_gaussian.conv_2d_cl_array_ap_fixed_1u_array_ap_fixed_29_12_5_3_0_6u_config2_U0'");
                                $fdisplay(fp, "Dependence_Channel_path gaussian_gaussian.layer34_out_U");
                                $fdisplay(fp, "Dependence_Channel_status EMPTY");
                            end
                            else if (~layer34_out_U.if_full_n) begin
                                $display("//      Blocked by full output FIFO 'gaussian_gaussian.layer34_out_U' read by process 'gaussian_gaussian.conv_2d_cl_array_ap_fixed_1u_array_ap_fixed_29_12_5_3_0_6u_config2_U0'");
                                $fdisplay(fp, "Dependence_Channel_path gaussian_gaussian.layer34_out_U");
                                $fdisplay(fp, "Dependence_Channel_status FULL");
                            end
                        end
// for dep channel 'gaussian_gaussian.start_for_conv_2d_cl_array_ap_fixed_1u_array_ap_fixed_29_12_5_3_0_6u_config2_U0_U' info is :
// blk sig is {{~gaussian_gaussian_inst.start_for_conv_2d_cl_array_ap_fixed_1u_array_ap_fixed_29_12_5_3_0_6u_config2_U0_U.if_full_n & gaussian_gaussian_inst.zeropad2d_cl_array_ap_fixed_1u_array_ap_fixed_16_6_5_3_0_1u_config34_U0.ap_start & ~gaussian_gaussian_inst.zeropad2d_cl_array_ap_fixed_1u_array_ap_fixed_16_6_5_3_0_1u_config34_U0.real_start & (trans_in_cnt_0 == trans_out_cnt_0) & ~gaussian_gaussian_inst.start_for_conv_2d_cl_array_ap_fixed_1u_array_ap_fixed_29_12_5_3_0_6u_config2_U0_U.if_read} start_FIFO}
                        if ((~start_for_conv_2d_cl_array_ap_fixed_1u_array_ap_fixed_29_12_5_3_0_6u_config2_U0_U.if_full_n & zeropad2d_cl_array_ap_fixed_1u_array_ap_fixed_16_6_5_3_0_1u_config34_U0.ap_start & ~zeropad2d_cl_array_ap_fixed_1u_array_ap_fixed_16_6_5_3_0_1u_config34_U0.real_start & (trans_in_cnt_0 == trans_out_cnt_0) & ~start_for_conv_2d_cl_array_ap_fixed_1u_array_ap_fixed_29_12_5_3_0_6u_config2_U0_U.if_read)) begin
                            $display("//      Blocked by full output start propagation FIFO 'gaussian_gaussian.start_for_conv_2d_cl_array_ap_fixed_1u_array_ap_fixed_29_12_5_3_0_6u_config2_U0_U' read by process 'gaussian_gaussian.conv_2d_cl_array_ap_fixed_1u_array_ap_fixed_29_12_5_3_0_6u_config2_U0',");
                        end
                    end
                    endcase
                end
                1 : begin // for proc 'gaussian_gaussian.conv_2d_cl_array_ap_fixed_1u_array_ap_fixed_29_12_5_3_0_6u_config2_U0'
                    case(index2)
                    0: begin //  for dep proc 'gaussian_gaussian.zeropad2d_cl_array_ap_fixed_1u_array_ap_fixed_16_6_5_3_0_1u_config34_U0'
// for dep channel 'gaussian_gaussian.layer34_out_U' info is :
// blk sig is {~gaussian_gaussian_inst.conv_2d_cl_array_ap_fixed_1u_array_ap_fixed_29_12_5_3_0_6u_config2_U0.layer34_out_blk_n data_FIFO}
                        if ((~conv_2d_cl_array_ap_fixed_1u_array_ap_fixed_29_12_5_3_0_6u_config2_U0.layer34_out_blk_n)) begin
                            if (~layer34_out_U.if_empty_n) begin
                                $display("//      Blocked by empty input FIFO 'gaussian_gaussian.layer34_out_U' written by process 'gaussian_gaussian.zeropad2d_cl_array_ap_fixed_1u_array_ap_fixed_16_6_5_3_0_1u_config34_U0'");
                                $fdisplay(fp, "Dependence_Channel_path gaussian_gaussian.layer34_out_U");
                                $fdisplay(fp, "Dependence_Channel_status EMPTY");
                            end
                            else if (~layer34_out_U.if_full_n) begin
                                $display("//      Blocked by full output FIFO 'gaussian_gaussian.layer34_out_U' read by process 'gaussian_gaussian.zeropad2d_cl_array_ap_fixed_1u_array_ap_fixed_16_6_5_3_0_1u_config34_U0'");
                                $fdisplay(fp, "Dependence_Channel_path gaussian_gaussian.layer34_out_U");
                                $fdisplay(fp, "Dependence_Channel_status FULL");
                            end
                        end
// for dep channel 'gaussian_gaussian.start_for_conv_2d_cl_array_ap_fixed_1u_array_ap_fixed_29_12_5_3_0_6u_config2_U0_U' info is :
// blk sig is {{~gaussian_gaussian_inst.start_for_conv_2d_cl_array_ap_fixed_1u_array_ap_fixed_29_12_5_3_0_6u_config2_U0_U.if_empty_n & gaussian_gaussian_inst.conv_2d_cl_array_ap_fixed_1u_array_ap_fixed_29_12_5_3_0_6u_config2_U0.ap_idle & ~gaussian_gaussian_inst.start_for_conv_2d_cl_array_ap_fixed_1u_array_ap_fixed_29_12_5_3_0_6u_config2_U0_U.if_write} start_FIFO}
                        if ((~start_for_conv_2d_cl_array_ap_fixed_1u_array_ap_fixed_29_12_5_3_0_6u_config2_U0_U.if_empty_n & conv_2d_cl_array_ap_fixed_1u_array_ap_fixed_29_12_5_3_0_6u_config2_U0.ap_idle & ~start_for_conv_2d_cl_array_ap_fixed_1u_array_ap_fixed_29_12_5_3_0_6u_config2_U0_U.if_write)) begin
                            $display("//      Blocked by missing 'ap_start' from start propagation FIFO 'gaussian_gaussian.start_for_conv_2d_cl_array_ap_fixed_1u_array_ap_fixed_29_12_5_3_0_6u_config2_U0_U' written by process 'gaussian_gaussian.zeropad2d_cl_array_ap_fixed_1u_array_ap_fixed_16_6_5_3_0_1u_config34_U0',");
                        end
                    end
                    2: begin //  for dep proc 'gaussian_gaussian.relu_array_ap_fixed_6u_array_ap_ufixed_8_0_4_0_0_6u_relu_config4_U0'
// for dep channel 'gaussian_gaussian.layer2_out_U' info is :
// blk sig is {~gaussian_gaussian_inst.conv_2d_cl_array_ap_fixed_1u_array_ap_fixed_29_12_5_3_0_6u_config2_U0.layer2_out_blk_n data_FIFO} {~gaussian_gaussian_inst.conv_2d_cl_array_ap_fixed_1u_array_ap_fixed_29_12_5_3_0_6u_config2_U0.grp_compute_output_buffer_2d_array_array_ap_fixed_29_12_5_3_0_6u_config2_s_fu_76.layer2_out_blk_n data_FIFO}
                        if ((~conv_2d_cl_array_ap_fixed_1u_array_ap_fixed_29_12_5_3_0_6u_config2_U0.layer2_out_blk_n) | (~conv_2d_cl_array_ap_fixed_1u_array_ap_fixed_29_12_5_3_0_6u_config2_U0.grp_compute_output_buffer_2d_array_array_ap_fixed_29_12_5_3_0_6u_config2_s_fu_76.layer2_out_blk_n)) begin
                            if (~layer2_out_U.if_empty_n) begin
                                $display("//      Blocked by empty input FIFO 'gaussian_gaussian.layer2_out_U' written by process 'gaussian_gaussian.relu_array_ap_fixed_6u_array_ap_ufixed_8_0_4_0_0_6u_relu_config4_U0'");
                                $fdisplay(fp, "Dependence_Channel_path gaussian_gaussian.layer2_out_U");
                                $fdisplay(fp, "Dependence_Channel_status EMPTY");
                            end
                            else if (~layer2_out_U.if_full_n) begin
                                $display("//      Blocked by full output FIFO 'gaussian_gaussian.layer2_out_U' read by process 'gaussian_gaussian.relu_array_ap_fixed_6u_array_ap_ufixed_8_0_4_0_0_6u_relu_config4_U0'");
                                $fdisplay(fp, "Dependence_Channel_path gaussian_gaussian.layer2_out_U");
                                $fdisplay(fp, "Dependence_Channel_status FULL");
                            end
                        end
// for dep channel 'gaussian_gaussian.start_for_relu_array_ap_fixed_6u_array_ap_ufixed_8_0_4_0_0_6u_relu_config4_U0_U' info is :
// blk sig is {{~gaussian_gaussian_inst.start_for_relu_array_ap_fixed_6u_array_ap_ufixed_8_0_4_0_0_6u_relu_config4_U0_U.if_full_n & gaussian_gaussian_inst.conv_2d_cl_array_ap_fixed_1u_array_ap_fixed_29_12_5_3_0_6u_config2_U0.ap_start & ~gaussian_gaussian_inst.conv_2d_cl_array_ap_fixed_1u_array_ap_fixed_29_12_5_3_0_6u_config2_U0.real_start & (trans_in_cnt_1 == trans_out_cnt_1) & ~gaussian_gaussian_inst.start_for_relu_array_ap_fixed_6u_array_ap_ufixed_8_0_4_0_0_6u_relu_config4_U0_U.if_read} start_FIFO}
                        if ((~start_for_relu_array_ap_fixed_6u_array_ap_ufixed_8_0_4_0_0_6u_relu_config4_U0_U.if_full_n & conv_2d_cl_array_ap_fixed_1u_array_ap_fixed_29_12_5_3_0_6u_config2_U0.ap_start & ~conv_2d_cl_array_ap_fixed_1u_array_ap_fixed_29_12_5_3_0_6u_config2_U0.real_start & (trans_in_cnt_1 == trans_out_cnt_1) & ~start_for_relu_array_ap_fixed_6u_array_ap_ufixed_8_0_4_0_0_6u_relu_config4_U0_U.if_read)) begin
                            $display("//      Blocked by full output start propagation FIFO 'gaussian_gaussian.start_for_relu_array_ap_fixed_6u_array_ap_ufixed_8_0_4_0_0_6u_relu_config4_U0_U' read by process 'gaussian_gaussian.relu_array_ap_fixed_6u_array_ap_ufixed_8_0_4_0_0_6u_relu_config4_U0',");
                        end
                    end
                    endcase
                end
                2 : begin // for proc 'gaussian_gaussian.relu_array_ap_fixed_6u_array_ap_ufixed_8_0_4_0_0_6u_relu_config4_U0'
                    case(index2)
                    1: begin //  for dep proc 'gaussian_gaussian.conv_2d_cl_array_ap_fixed_1u_array_ap_fixed_29_12_5_3_0_6u_config2_U0'
// for dep channel 'gaussian_gaussian.layer2_out_U' info is :
// blk sig is {~gaussian_gaussian_inst.relu_array_ap_fixed_6u_array_ap_ufixed_8_0_4_0_0_6u_relu_config4_U0.layer2_out_blk_n data_FIFO}
                        if ((~relu_array_ap_fixed_6u_array_ap_ufixed_8_0_4_0_0_6u_relu_config4_U0.layer2_out_blk_n)) begin
                            if (~layer2_out_U.if_empty_n) begin
                                $display("//      Blocked by empty input FIFO 'gaussian_gaussian.layer2_out_U' written by process 'gaussian_gaussian.conv_2d_cl_array_ap_fixed_1u_array_ap_fixed_29_12_5_3_0_6u_config2_U0'");
                                $fdisplay(fp, "Dependence_Channel_path gaussian_gaussian.layer2_out_U");
                                $fdisplay(fp, "Dependence_Channel_status EMPTY");
                            end
                            else if (~layer2_out_U.if_full_n) begin
                                $display("//      Blocked by full output FIFO 'gaussian_gaussian.layer2_out_U' read by process 'gaussian_gaussian.conv_2d_cl_array_ap_fixed_1u_array_ap_fixed_29_12_5_3_0_6u_config2_U0'");
                                $fdisplay(fp, "Dependence_Channel_path gaussian_gaussian.layer2_out_U");
                                $fdisplay(fp, "Dependence_Channel_status FULL");
                            end
                        end
// for dep channel 'gaussian_gaussian.start_for_relu_array_ap_fixed_6u_array_ap_ufixed_8_0_4_0_0_6u_relu_config4_U0_U' info is :
// blk sig is {{~gaussian_gaussian_inst.start_for_relu_array_ap_fixed_6u_array_ap_ufixed_8_0_4_0_0_6u_relu_config4_U0_U.if_empty_n & gaussian_gaussian_inst.relu_array_ap_fixed_6u_array_ap_ufixed_8_0_4_0_0_6u_relu_config4_U0.ap_idle & ~gaussian_gaussian_inst.start_for_relu_array_ap_fixed_6u_array_ap_ufixed_8_0_4_0_0_6u_relu_config4_U0_U.if_write} start_FIFO}
                        if ((~start_for_relu_array_ap_fixed_6u_array_ap_ufixed_8_0_4_0_0_6u_relu_config4_U0_U.if_empty_n & relu_array_ap_fixed_6u_array_ap_ufixed_8_0_4_0_0_6u_relu_config4_U0.ap_idle & ~start_for_relu_array_ap_fixed_6u_array_ap_ufixed_8_0_4_0_0_6u_relu_config4_U0_U.if_write)) begin
                            $display("//      Blocked by missing 'ap_start' from start propagation FIFO 'gaussian_gaussian.start_for_relu_array_ap_fixed_6u_array_ap_ufixed_8_0_4_0_0_6u_relu_config4_U0_U' written by process 'gaussian_gaussian.conv_2d_cl_array_ap_fixed_1u_array_ap_fixed_29_12_5_3_0_6u_config2_U0',");
                        end
                    end
                    3: begin //  for dep proc 'gaussian_gaussian.pooling2d_cl_array_ap_ufixed_6u_array_ap_ufixed_8_0_4_0_0_6u_config5_U0'
// for dep channel 'gaussian_gaussian.layer4_out_U' info is :
// blk sig is {~gaussian_gaussian_inst.relu_array_ap_fixed_6u_array_ap_ufixed_8_0_4_0_0_6u_relu_config4_U0.layer4_out_blk_n data_FIFO}
                        if ((~relu_array_ap_fixed_6u_array_ap_ufixed_8_0_4_0_0_6u_relu_config4_U0.layer4_out_blk_n)) begin
                            if (~layer4_out_U.if_empty_n) begin
                                $display("//      Blocked by empty input FIFO 'gaussian_gaussian.layer4_out_U' written by process 'gaussian_gaussian.pooling2d_cl_array_ap_ufixed_6u_array_ap_ufixed_8_0_4_0_0_6u_config5_U0'");
                                $fdisplay(fp, "Dependence_Channel_path gaussian_gaussian.layer4_out_U");
                                $fdisplay(fp, "Dependence_Channel_status EMPTY");
                            end
                            else if (~layer4_out_U.if_full_n) begin
                                $display("//      Blocked by full output FIFO 'gaussian_gaussian.layer4_out_U' read by process 'gaussian_gaussian.pooling2d_cl_array_ap_ufixed_6u_array_ap_ufixed_8_0_4_0_0_6u_config5_U0'");
                                $fdisplay(fp, "Dependence_Channel_path gaussian_gaussian.layer4_out_U");
                                $fdisplay(fp, "Dependence_Channel_status FULL");
                            end
                        end
// for dep channel 'gaussian_gaussian.start_for_pooling2d_cl_array_ap_ufixed_6u_array_ap_ufixed_8_0_4_0_0_6u_configJfO_U' info is :
// blk sig is {{~gaussian_gaussian_inst.start_for_pooling2d_cl_array_ap_ufixed_6u_array_ap_ufixed_8_0_4_0_0_6u_configJfO_U.if_full_n & gaussian_gaussian_inst.relu_array_ap_fixed_6u_array_ap_ufixed_8_0_4_0_0_6u_relu_config4_U0.ap_start & ~gaussian_gaussian_inst.relu_array_ap_fixed_6u_array_ap_ufixed_8_0_4_0_0_6u_relu_config4_U0.real_start & (trans_in_cnt_2 == trans_out_cnt_2) & ~gaussian_gaussian_inst.start_for_pooling2d_cl_array_ap_ufixed_6u_array_ap_ufixed_8_0_4_0_0_6u_configJfO_U.if_read} start_FIFO}
                        if ((~start_for_pooling2d_cl_array_ap_ufixed_6u_array_ap_ufixed_8_0_4_0_0_6u_configJfO_U.if_full_n & relu_array_ap_fixed_6u_array_ap_ufixed_8_0_4_0_0_6u_relu_config4_U0.ap_start & ~relu_array_ap_fixed_6u_array_ap_ufixed_8_0_4_0_0_6u_relu_config4_U0.real_start & (trans_in_cnt_2 == trans_out_cnt_2) & ~start_for_pooling2d_cl_array_ap_ufixed_6u_array_ap_ufixed_8_0_4_0_0_6u_configJfO_U.if_read)) begin
                            $display("//      Blocked by full output start propagation FIFO 'gaussian_gaussian.start_for_pooling2d_cl_array_ap_ufixed_6u_array_ap_ufixed_8_0_4_0_0_6u_configJfO_U' read by process 'gaussian_gaussian.pooling2d_cl_array_ap_ufixed_6u_array_ap_ufixed_8_0_4_0_0_6u_config5_U0',");
                        end
                    end
                    endcase
                end
                3 : begin // for proc 'gaussian_gaussian.pooling2d_cl_array_ap_ufixed_6u_array_ap_ufixed_8_0_4_0_0_6u_config5_U0'
                    case(index2)
                    2: begin //  for dep proc 'gaussian_gaussian.relu_array_ap_fixed_6u_array_ap_ufixed_8_0_4_0_0_6u_relu_config4_U0'
// for dep channel 'gaussian_gaussian.layer4_out_U' info is :
// blk sig is {~gaussian_gaussian_inst.pooling2d_cl_array_ap_ufixed_6u_array_ap_ufixed_8_0_4_0_0_6u_config5_U0.layer4_out_blk_n data_FIFO}
                        if ((~pooling2d_cl_array_ap_ufixed_6u_array_ap_ufixed_8_0_4_0_0_6u_config5_U0.layer4_out_blk_n)) begin
                            if (~layer4_out_U.if_empty_n) begin
                                $display("//      Blocked by empty input FIFO 'gaussian_gaussian.layer4_out_U' written by process 'gaussian_gaussian.relu_array_ap_fixed_6u_array_ap_ufixed_8_0_4_0_0_6u_relu_config4_U0'");
                                $fdisplay(fp, "Dependence_Channel_path gaussian_gaussian.layer4_out_U");
                                $fdisplay(fp, "Dependence_Channel_status EMPTY");
                            end
                            else if (~layer4_out_U.if_full_n) begin
                                $display("//      Blocked by full output FIFO 'gaussian_gaussian.layer4_out_U' read by process 'gaussian_gaussian.relu_array_ap_fixed_6u_array_ap_ufixed_8_0_4_0_0_6u_relu_config4_U0'");
                                $fdisplay(fp, "Dependence_Channel_path gaussian_gaussian.layer4_out_U");
                                $fdisplay(fp, "Dependence_Channel_status FULL");
                            end
                        end
// for dep channel 'gaussian_gaussian.start_for_pooling2d_cl_array_ap_ufixed_6u_array_ap_ufixed_8_0_4_0_0_6u_configJfO_U' info is :
// blk sig is {{~gaussian_gaussian_inst.start_for_pooling2d_cl_array_ap_ufixed_6u_array_ap_ufixed_8_0_4_0_0_6u_configJfO_U.if_empty_n & gaussian_gaussian_inst.pooling2d_cl_array_ap_ufixed_6u_array_ap_ufixed_8_0_4_0_0_6u_config5_U0.ap_idle & ~gaussian_gaussian_inst.start_for_pooling2d_cl_array_ap_ufixed_6u_array_ap_ufixed_8_0_4_0_0_6u_configJfO_U.if_write} start_FIFO}
                        if ((~start_for_pooling2d_cl_array_ap_ufixed_6u_array_ap_ufixed_8_0_4_0_0_6u_configJfO_U.if_empty_n & pooling2d_cl_array_ap_ufixed_6u_array_ap_ufixed_8_0_4_0_0_6u_config5_U0.ap_idle & ~start_for_pooling2d_cl_array_ap_ufixed_6u_array_ap_ufixed_8_0_4_0_0_6u_configJfO_U.if_write)) begin
                            $display("//      Blocked by missing 'ap_start' from start propagation FIFO 'gaussian_gaussian.start_for_pooling2d_cl_array_ap_ufixed_6u_array_ap_ufixed_8_0_4_0_0_6u_configJfO_U' written by process 'gaussian_gaussian.relu_array_ap_fixed_6u_array_ap_ufixed_8_0_4_0_0_6u_relu_config4_U0',");
                        end
                    end
                    4: begin //  for dep proc 'gaussian_gaussian.zeropad2d_cl_array_array_ap_ufixed_8_0_4_0_0_6u_config35_U0'
// for dep channel 'gaussian_gaussian.layer5_out_U' info is :
// blk sig is {~gaussian_gaussian_inst.pooling2d_cl_array_ap_ufixed_6u_array_ap_ufixed_8_0_4_0_0_6u_config5_U0.layer5_out_blk_n data_FIFO}
                        if ((~pooling2d_cl_array_ap_ufixed_6u_array_ap_ufixed_8_0_4_0_0_6u_config5_U0.layer5_out_blk_n)) begin
                            if (~layer5_out_U.if_empty_n) begin
                                $display("//      Blocked by empty input FIFO 'gaussian_gaussian.layer5_out_U' written by process 'gaussian_gaussian.zeropad2d_cl_array_array_ap_ufixed_8_0_4_0_0_6u_config35_U0'");
                                $fdisplay(fp, "Dependence_Channel_path gaussian_gaussian.layer5_out_U");
                                $fdisplay(fp, "Dependence_Channel_status EMPTY");
                            end
                            else if (~layer5_out_U.if_full_n) begin
                                $display("//      Blocked by full output FIFO 'gaussian_gaussian.layer5_out_U' read by process 'gaussian_gaussian.zeropad2d_cl_array_array_ap_ufixed_8_0_4_0_0_6u_config35_U0'");
                                $fdisplay(fp, "Dependence_Channel_path gaussian_gaussian.layer5_out_U");
                                $fdisplay(fp, "Dependence_Channel_status FULL");
                            end
                        end
// for dep channel 'gaussian_gaussian.start_for_zeropad2d_cl_array_array_ap_ufixed_8_0_4_0_0_6u_config35_U0_U' info is :
// blk sig is {{~gaussian_gaussian_inst.start_for_zeropad2d_cl_array_array_ap_ufixed_8_0_4_0_0_6u_config35_U0_U.if_full_n & gaussian_gaussian_inst.pooling2d_cl_array_ap_ufixed_6u_array_ap_ufixed_8_0_4_0_0_6u_config5_U0.ap_start & ~gaussian_gaussian_inst.pooling2d_cl_array_ap_ufixed_6u_array_ap_ufixed_8_0_4_0_0_6u_config5_U0.real_start & (trans_in_cnt_3 == trans_out_cnt_3) & ~gaussian_gaussian_inst.start_for_zeropad2d_cl_array_array_ap_ufixed_8_0_4_0_0_6u_config35_U0_U.if_read} start_FIFO}
                        if ((~start_for_zeropad2d_cl_array_array_ap_ufixed_8_0_4_0_0_6u_config35_U0_U.if_full_n & pooling2d_cl_array_ap_ufixed_6u_array_ap_ufixed_8_0_4_0_0_6u_config5_U0.ap_start & ~pooling2d_cl_array_ap_ufixed_6u_array_ap_ufixed_8_0_4_0_0_6u_config5_U0.real_start & (trans_in_cnt_3 == trans_out_cnt_3) & ~start_for_zeropad2d_cl_array_array_ap_ufixed_8_0_4_0_0_6u_config35_U0_U.if_read)) begin
                            $display("//      Blocked by full output start propagation FIFO 'gaussian_gaussian.start_for_zeropad2d_cl_array_array_ap_ufixed_8_0_4_0_0_6u_config35_U0_U' read by process 'gaussian_gaussian.zeropad2d_cl_array_array_ap_ufixed_8_0_4_0_0_6u_config35_U0',");
                        end
                    end
                    endcase
                end
                4 : begin // for proc 'gaussian_gaussian.zeropad2d_cl_array_array_ap_ufixed_8_0_4_0_0_6u_config35_U0'
                    case(index2)
                    3: begin //  for dep proc 'gaussian_gaussian.pooling2d_cl_array_ap_ufixed_6u_array_ap_ufixed_8_0_4_0_0_6u_config5_U0'
// for dep channel 'gaussian_gaussian.layer5_out_U' info is :
// blk sig is {~gaussian_gaussian_inst.zeropad2d_cl_array_array_ap_ufixed_8_0_4_0_0_6u_config35_U0.grp_zeropad2d_cl_array_array_ap_ufixed_8_0_4_0_0_6u_config35_Pipeline_PadMain_fu_28.layer5_out_blk_n data_FIFO}
                        if ((~zeropad2d_cl_array_array_ap_ufixed_8_0_4_0_0_6u_config35_U0.grp_zeropad2d_cl_array_array_ap_ufixed_8_0_4_0_0_6u_config35_Pipeline_PadMain_fu_28.layer5_out_blk_n)) begin
                            if (~layer5_out_U.if_empty_n) begin
                                $display("//      Blocked by empty input FIFO 'gaussian_gaussian.layer5_out_U' written by process 'gaussian_gaussian.pooling2d_cl_array_ap_ufixed_6u_array_ap_ufixed_8_0_4_0_0_6u_config5_U0'");
                                $fdisplay(fp, "Dependence_Channel_path gaussian_gaussian.layer5_out_U");
                                $fdisplay(fp, "Dependence_Channel_status EMPTY");
                            end
                            else if (~layer5_out_U.if_full_n) begin
                                $display("//      Blocked by full output FIFO 'gaussian_gaussian.layer5_out_U' read by process 'gaussian_gaussian.pooling2d_cl_array_ap_ufixed_6u_array_ap_ufixed_8_0_4_0_0_6u_config5_U0'");
                                $fdisplay(fp, "Dependence_Channel_path gaussian_gaussian.layer5_out_U");
                                $fdisplay(fp, "Dependence_Channel_status FULL");
                            end
                        end
// for dep channel 'gaussian_gaussian.start_for_zeropad2d_cl_array_array_ap_ufixed_8_0_4_0_0_6u_config35_U0_U' info is :
// blk sig is {{~gaussian_gaussian_inst.start_for_zeropad2d_cl_array_array_ap_ufixed_8_0_4_0_0_6u_config35_U0_U.if_empty_n & gaussian_gaussian_inst.zeropad2d_cl_array_array_ap_ufixed_8_0_4_0_0_6u_config35_U0.ap_idle & ~gaussian_gaussian_inst.start_for_zeropad2d_cl_array_array_ap_ufixed_8_0_4_0_0_6u_config35_U0_U.if_write} start_FIFO}
                        if ((~start_for_zeropad2d_cl_array_array_ap_ufixed_8_0_4_0_0_6u_config35_U0_U.if_empty_n & zeropad2d_cl_array_array_ap_ufixed_8_0_4_0_0_6u_config35_U0.ap_idle & ~start_for_zeropad2d_cl_array_array_ap_ufixed_8_0_4_0_0_6u_config35_U0_U.if_write)) begin
                            $display("//      Blocked by missing 'ap_start' from start propagation FIFO 'gaussian_gaussian.start_for_zeropad2d_cl_array_array_ap_ufixed_8_0_4_0_0_6u_config35_U0_U' written by process 'gaussian_gaussian.pooling2d_cl_array_ap_ufixed_6u_array_ap_ufixed_8_0_4_0_0_6u_config5_U0',");
                        end
                    end
                    5: begin //  for dep proc 'gaussian_gaussian.conv_2d_cl_array_ap_ufixed_6u_array_ap_fixed_23_8_5_3_0_8u_config6_U0'
// for dep channel 'gaussian_gaussian.layer35_out_U' info is :
// blk sig is {~gaussian_gaussian_inst.zeropad2d_cl_array_array_ap_ufixed_8_0_4_0_0_6u_config35_U0.grp_zeropad2d_cl_array_array_ap_ufixed_8_0_4_0_0_6u_config35_Pipeline_PadTopWidth_fu_22.layer35_out_blk_n data_FIFO}
                        if ((~zeropad2d_cl_array_array_ap_ufixed_8_0_4_0_0_6u_config35_U0.grp_zeropad2d_cl_array_array_ap_ufixed_8_0_4_0_0_6u_config35_Pipeline_PadTopWidth_fu_22.layer35_out_blk_n)) begin
                            if (~layer35_out_U.if_empty_n) begin
                                $display("//      Blocked by empty input FIFO 'gaussian_gaussian.layer35_out_U' written by process 'gaussian_gaussian.conv_2d_cl_array_ap_ufixed_6u_array_ap_fixed_23_8_5_3_0_8u_config6_U0'");
                                $fdisplay(fp, "Dependence_Channel_path gaussian_gaussian.layer35_out_U");
                                $fdisplay(fp, "Dependence_Channel_status EMPTY");
                            end
                            else if (~layer35_out_U.if_full_n) begin
                                $display("//      Blocked by full output FIFO 'gaussian_gaussian.layer35_out_U' read by process 'gaussian_gaussian.conv_2d_cl_array_ap_ufixed_6u_array_ap_fixed_23_8_5_3_0_8u_config6_U0'");
                                $fdisplay(fp, "Dependence_Channel_path gaussian_gaussian.layer35_out_U");
                                $fdisplay(fp, "Dependence_Channel_status FULL");
                            end
                        end
// for dep channel 'gaussian_gaussian.start_for_conv_2d_cl_array_ap_ufixed_6u_array_ap_fixed_23_8_5_3_0_8u_config6_U0_U' info is :
// blk sig is {{~gaussian_gaussian_inst.start_for_conv_2d_cl_array_ap_ufixed_6u_array_ap_fixed_23_8_5_3_0_8u_config6_U0_U.if_full_n & gaussian_gaussian_inst.zeropad2d_cl_array_array_ap_ufixed_8_0_4_0_0_6u_config35_U0.ap_start & ~gaussian_gaussian_inst.zeropad2d_cl_array_array_ap_ufixed_8_0_4_0_0_6u_config35_U0.real_start & (trans_in_cnt_4 == trans_out_cnt_4) & ~gaussian_gaussian_inst.start_for_conv_2d_cl_array_ap_ufixed_6u_array_ap_fixed_23_8_5_3_0_8u_config6_U0_U.if_read} start_FIFO}
                        if ((~start_for_conv_2d_cl_array_ap_ufixed_6u_array_ap_fixed_23_8_5_3_0_8u_config6_U0_U.if_full_n & zeropad2d_cl_array_array_ap_ufixed_8_0_4_0_0_6u_config35_U0.ap_start & ~zeropad2d_cl_array_array_ap_ufixed_8_0_4_0_0_6u_config35_U0.real_start & (trans_in_cnt_4 == trans_out_cnt_4) & ~start_for_conv_2d_cl_array_ap_ufixed_6u_array_ap_fixed_23_8_5_3_0_8u_config6_U0_U.if_read)) begin
                            $display("//      Blocked by full output start propagation FIFO 'gaussian_gaussian.start_for_conv_2d_cl_array_ap_ufixed_6u_array_ap_fixed_23_8_5_3_0_8u_config6_U0_U' read by process 'gaussian_gaussian.conv_2d_cl_array_ap_ufixed_6u_array_ap_fixed_23_8_5_3_0_8u_config6_U0',");
                        end
                    end
                    endcase
                end
                5 : begin // for proc 'gaussian_gaussian.conv_2d_cl_array_ap_ufixed_6u_array_ap_fixed_23_8_5_3_0_8u_config6_U0'
                    case(index2)
                    4: begin //  for dep proc 'gaussian_gaussian.zeropad2d_cl_array_array_ap_ufixed_8_0_4_0_0_6u_config35_U0'
// for dep channel 'gaussian_gaussian.layer35_out_U' info is :
// blk sig is {~gaussian_gaussian_inst.conv_2d_cl_array_ap_ufixed_6u_array_ap_fixed_23_8_5_3_0_8u_config6_U0.layer35_out_blk_n data_FIFO}
                        if ((~conv_2d_cl_array_ap_ufixed_6u_array_ap_fixed_23_8_5_3_0_8u_config6_U0.layer35_out_blk_n)) begin
                            if (~layer35_out_U.if_empty_n) begin
                                $display("//      Blocked by empty input FIFO 'gaussian_gaussian.layer35_out_U' written by process 'gaussian_gaussian.zeropad2d_cl_array_array_ap_ufixed_8_0_4_0_0_6u_config35_U0'");
                                $fdisplay(fp, "Dependence_Channel_path gaussian_gaussian.layer35_out_U");
                                $fdisplay(fp, "Dependence_Channel_status EMPTY");
                            end
                            else if (~layer35_out_U.if_full_n) begin
                                $display("//      Blocked by full output FIFO 'gaussian_gaussian.layer35_out_U' read by process 'gaussian_gaussian.zeropad2d_cl_array_array_ap_ufixed_8_0_4_0_0_6u_config35_U0'");
                                $fdisplay(fp, "Dependence_Channel_path gaussian_gaussian.layer35_out_U");
                                $fdisplay(fp, "Dependence_Channel_status FULL");
                            end
                        end
// for dep channel 'gaussian_gaussian.start_for_conv_2d_cl_array_ap_ufixed_6u_array_ap_fixed_23_8_5_3_0_8u_config6_U0_U' info is :
// blk sig is {{~gaussian_gaussian_inst.start_for_conv_2d_cl_array_ap_ufixed_6u_array_ap_fixed_23_8_5_3_0_8u_config6_U0_U.if_empty_n & gaussian_gaussian_inst.conv_2d_cl_array_ap_ufixed_6u_array_ap_fixed_23_8_5_3_0_8u_config6_U0.ap_idle & ~gaussian_gaussian_inst.start_for_conv_2d_cl_array_ap_ufixed_6u_array_ap_fixed_23_8_5_3_0_8u_config6_U0_U.if_write} start_FIFO}
                        if ((~start_for_conv_2d_cl_array_ap_ufixed_6u_array_ap_fixed_23_8_5_3_0_8u_config6_U0_U.if_empty_n & conv_2d_cl_array_ap_ufixed_6u_array_ap_fixed_23_8_5_3_0_8u_config6_U0.ap_idle & ~start_for_conv_2d_cl_array_ap_ufixed_6u_array_ap_fixed_23_8_5_3_0_8u_config6_U0_U.if_write)) begin
                            $display("//      Blocked by missing 'ap_start' from start propagation FIFO 'gaussian_gaussian.start_for_conv_2d_cl_array_ap_ufixed_6u_array_ap_fixed_23_8_5_3_0_8u_config6_U0_U' written by process 'gaussian_gaussian.zeropad2d_cl_array_array_ap_ufixed_8_0_4_0_0_6u_config35_U0',");
                        end
                    end
                    6: begin //  for dep proc 'gaussian_gaussian.relu_array_ap_fixed_8u_array_ap_ufixed_8_0_4_0_0_8u_relu_config8_U0'
// for dep channel 'gaussian_gaussian.layer6_out_U' info is :
// blk sig is {~gaussian_gaussian_inst.conv_2d_cl_array_ap_ufixed_6u_array_ap_fixed_23_8_5_3_0_8u_config6_U0.layer6_out_blk_n data_FIFO} {~gaussian_gaussian_inst.conv_2d_cl_array_ap_ufixed_6u_array_ap_fixed_23_8_5_3_0_8u_config6_U0.grp_compute_output_buffer_2d_array_array_ap_fixed_23_8_5_3_0_8u_config6_s_fu_208.layer6_out_blk_n data_FIFO}
                        if ((~conv_2d_cl_array_ap_ufixed_6u_array_ap_fixed_23_8_5_3_0_8u_config6_U0.layer6_out_blk_n) | (~conv_2d_cl_array_ap_ufixed_6u_array_ap_fixed_23_8_5_3_0_8u_config6_U0.grp_compute_output_buffer_2d_array_array_ap_fixed_23_8_5_3_0_8u_config6_s_fu_208.layer6_out_blk_n)) begin
                            if (~layer6_out_U.if_empty_n) begin
                                $display("//      Blocked by empty input FIFO 'gaussian_gaussian.layer6_out_U' written by process 'gaussian_gaussian.relu_array_ap_fixed_8u_array_ap_ufixed_8_0_4_0_0_8u_relu_config8_U0'");
                                $fdisplay(fp, "Dependence_Channel_path gaussian_gaussian.layer6_out_U");
                                $fdisplay(fp, "Dependence_Channel_status EMPTY");
                            end
                            else if (~layer6_out_U.if_full_n) begin
                                $display("//      Blocked by full output FIFO 'gaussian_gaussian.layer6_out_U' read by process 'gaussian_gaussian.relu_array_ap_fixed_8u_array_ap_ufixed_8_0_4_0_0_8u_relu_config8_U0'");
                                $fdisplay(fp, "Dependence_Channel_path gaussian_gaussian.layer6_out_U");
                                $fdisplay(fp, "Dependence_Channel_status FULL");
                            end
                        end
// for dep channel 'gaussian_gaussian.start_for_relu_array_ap_fixed_8u_array_ap_ufixed_8_0_4_0_0_8u_relu_config8_U0_U' info is :
// blk sig is {{~gaussian_gaussian_inst.start_for_relu_array_ap_fixed_8u_array_ap_ufixed_8_0_4_0_0_8u_relu_config8_U0_U.if_full_n & gaussian_gaussian_inst.conv_2d_cl_array_ap_ufixed_6u_array_ap_fixed_23_8_5_3_0_8u_config6_U0.ap_start & ~gaussian_gaussian_inst.conv_2d_cl_array_ap_ufixed_6u_array_ap_fixed_23_8_5_3_0_8u_config6_U0.real_start & (trans_in_cnt_5 == trans_out_cnt_5) & ~gaussian_gaussian_inst.start_for_relu_array_ap_fixed_8u_array_ap_ufixed_8_0_4_0_0_8u_relu_config8_U0_U.if_read} start_FIFO}
                        if ((~start_for_relu_array_ap_fixed_8u_array_ap_ufixed_8_0_4_0_0_8u_relu_config8_U0_U.if_full_n & conv_2d_cl_array_ap_ufixed_6u_array_ap_fixed_23_8_5_3_0_8u_config6_U0.ap_start & ~conv_2d_cl_array_ap_ufixed_6u_array_ap_fixed_23_8_5_3_0_8u_config6_U0.real_start & (trans_in_cnt_5 == trans_out_cnt_5) & ~start_for_relu_array_ap_fixed_8u_array_ap_ufixed_8_0_4_0_0_8u_relu_config8_U0_U.if_read)) begin
                            $display("//      Blocked by full output start propagation FIFO 'gaussian_gaussian.start_for_relu_array_ap_fixed_8u_array_ap_ufixed_8_0_4_0_0_8u_relu_config8_U0_U' read by process 'gaussian_gaussian.relu_array_ap_fixed_8u_array_ap_ufixed_8_0_4_0_0_8u_relu_config8_U0',");
                        end
                    end
                    endcase
                end
                6 : begin // for proc 'gaussian_gaussian.relu_array_ap_fixed_8u_array_ap_ufixed_8_0_4_0_0_8u_relu_config8_U0'
                    case(index2)
                    5: begin //  for dep proc 'gaussian_gaussian.conv_2d_cl_array_ap_ufixed_6u_array_ap_fixed_23_8_5_3_0_8u_config6_U0'
// for dep channel 'gaussian_gaussian.layer6_out_U' info is :
// blk sig is {~gaussian_gaussian_inst.relu_array_ap_fixed_8u_array_ap_ufixed_8_0_4_0_0_8u_relu_config8_U0.layer6_out_blk_n data_FIFO}
                        if ((~relu_array_ap_fixed_8u_array_ap_ufixed_8_0_4_0_0_8u_relu_config8_U0.layer6_out_blk_n)) begin
                            if (~layer6_out_U.if_empty_n) begin
                                $display("//      Blocked by empty input FIFO 'gaussian_gaussian.layer6_out_U' written by process 'gaussian_gaussian.conv_2d_cl_array_ap_ufixed_6u_array_ap_fixed_23_8_5_3_0_8u_config6_U0'");
                                $fdisplay(fp, "Dependence_Channel_path gaussian_gaussian.layer6_out_U");
                                $fdisplay(fp, "Dependence_Channel_status EMPTY");
                            end
                            else if (~layer6_out_U.if_full_n) begin
                                $display("//      Blocked by full output FIFO 'gaussian_gaussian.layer6_out_U' read by process 'gaussian_gaussian.conv_2d_cl_array_ap_ufixed_6u_array_ap_fixed_23_8_5_3_0_8u_config6_U0'");
                                $fdisplay(fp, "Dependence_Channel_path gaussian_gaussian.layer6_out_U");
                                $fdisplay(fp, "Dependence_Channel_status FULL");
                            end
                        end
// for dep channel 'gaussian_gaussian.start_for_relu_array_ap_fixed_8u_array_ap_ufixed_8_0_4_0_0_8u_relu_config8_U0_U' info is :
// blk sig is {{~gaussian_gaussian_inst.start_for_relu_array_ap_fixed_8u_array_ap_ufixed_8_0_4_0_0_8u_relu_config8_U0_U.if_empty_n & gaussian_gaussian_inst.relu_array_ap_fixed_8u_array_ap_ufixed_8_0_4_0_0_8u_relu_config8_U0.ap_idle & ~gaussian_gaussian_inst.start_for_relu_array_ap_fixed_8u_array_ap_ufixed_8_0_4_0_0_8u_relu_config8_U0_U.if_write} start_FIFO}
                        if ((~start_for_relu_array_ap_fixed_8u_array_ap_ufixed_8_0_4_0_0_8u_relu_config8_U0_U.if_empty_n & relu_array_ap_fixed_8u_array_ap_ufixed_8_0_4_0_0_8u_relu_config8_U0.ap_idle & ~start_for_relu_array_ap_fixed_8u_array_ap_ufixed_8_0_4_0_0_8u_relu_config8_U0_U.if_write)) begin
                            $display("//      Blocked by missing 'ap_start' from start propagation FIFO 'gaussian_gaussian.start_for_relu_array_ap_fixed_8u_array_ap_ufixed_8_0_4_0_0_8u_relu_config8_U0_U' written by process 'gaussian_gaussian.conv_2d_cl_array_ap_ufixed_6u_array_ap_fixed_23_8_5_3_0_8u_config6_U0',");
                        end
                    end
                    7: begin //  for dep proc 'gaussian_gaussian.pooling2d_cl_array_ap_ufixed_8u_array_ap_ufixed_8_0_4_0_0_8u_config9_U0'
// for dep channel 'gaussian_gaussian.layer8_out_U' info is :
// blk sig is {~gaussian_gaussian_inst.relu_array_ap_fixed_8u_array_ap_ufixed_8_0_4_0_0_8u_relu_config8_U0.layer8_out_blk_n data_FIFO}
                        if ((~relu_array_ap_fixed_8u_array_ap_ufixed_8_0_4_0_0_8u_relu_config8_U0.layer8_out_blk_n)) begin
                            if (~layer8_out_U.if_empty_n) begin
                                $display("//      Blocked by empty input FIFO 'gaussian_gaussian.layer8_out_U' written by process 'gaussian_gaussian.pooling2d_cl_array_ap_ufixed_8u_array_ap_ufixed_8_0_4_0_0_8u_config9_U0'");
                                $fdisplay(fp, "Dependence_Channel_path gaussian_gaussian.layer8_out_U");
                                $fdisplay(fp, "Dependence_Channel_status EMPTY");
                            end
                            else if (~layer8_out_U.if_full_n) begin
                                $display("//      Blocked by full output FIFO 'gaussian_gaussian.layer8_out_U' read by process 'gaussian_gaussian.pooling2d_cl_array_ap_ufixed_8u_array_ap_ufixed_8_0_4_0_0_8u_config9_U0'");
                                $fdisplay(fp, "Dependence_Channel_path gaussian_gaussian.layer8_out_U");
                                $fdisplay(fp, "Dependence_Channel_status FULL");
                            end
                        end
// for dep channel 'gaussian_gaussian.start_for_pooling2d_cl_array_ap_ufixed_8u_array_ap_ufixed_8_0_4_0_0_8u_configKfY_U' info is :
// blk sig is {{~gaussian_gaussian_inst.start_for_pooling2d_cl_array_ap_ufixed_8u_array_ap_ufixed_8_0_4_0_0_8u_configKfY_U.if_full_n & gaussian_gaussian_inst.relu_array_ap_fixed_8u_array_ap_ufixed_8_0_4_0_0_8u_relu_config8_U0.ap_start & ~gaussian_gaussian_inst.relu_array_ap_fixed_8u_array_ap_ufixed_8_0_4_0_0_8u_relu_config8_U0.real_start & (trans_in_cnt_6 == trans_out_cnt_6) & ~gaussian_gaussian_inst.start_for_pooling2d_cl_array_ap_ufixed_8u_array_ap_ufixed_8_0_4_0_0_8u_configKfY_U.if_read} start_FIFO}
                        if ((~start_for_pooling2d_cl_array_ap_ufixed_8u_array_ap_ufixed_8_0_4_0_0_8u_configKfY_U.if_full_n & relu_array_ap_fixed_8u_array_ap_ufixed_8_0_4_0_0_8u_relu_config8_U0.ap_start & ~relu_array_ap_fixed_8u_array_ap_ufixed_8_0_4_0_0_8u_relu_config8_U0.real_start & (trans_in_cnt_6 == trans_out_cnt_6) & ~start_for_pooling2d_cl_array_ap_ufixed_8u_array_ap_ufixed_8_0_4_0_0_8u_configKfY_U.if_read)) begin
                            $display("//      Blocked by full output start propagation FIFO 'gaussian_gaussian.start_for_pooling2d_cl_array_ap_ufixed_8u_array_ap_ufixed_8_0_4_0_0_8u_configKfY_U' read by process 'gaussian_gaussian.pooling2d_cl_array_ap_ufixed_8u_array_ap_ufixed_8_0_4_0_0_8u_config9_U0',");
                        end
                    end
                    endcase
                end
                7 : begin // for proc 'gaussian_gaussian.pooling2d_cl_array_ap_ufixed_8u_array_ap_ufixed_8_0_4_0_0_8u_config9_U0'
                    case(index2)
                    6: begin //  for dep proc 'gaussian_gaussian.relu_array_ap_fixed_8u_array_ap_ufixed_8_0_4_0_0_8u_relu_config8_U0'
// for dep channel 'gaussian_gaussian.layer8_out_U' info is :
// blk sig is {~gaussian_gaussian_inst.pooling2d_cl_array_ap_ufixed_8u_array_ap_ufixed_8_0_4_0_0_8u_config9_U0.layer8_out_blk_n data_FIFO}
                        if ((~pooling2d_cl_array_ap_ufixed_8u_array_ap_ufixed_8_0_4_0_0_8u_config9_U0.layer8_out_blk_n)) begin
                            if (~layer8_out_U.if_empty_n) begin
                                $display("//      Blocked by empty input FIFO 'gaussian_gaussian.layer8_out_U' written by process 'gaussian_gaussian.relu_array_ap_fixed_8u_array_ap_ufixed_8_0_4_0_0_8u_relu_config8_U0'");
                                $fdisplay(fp, "Dependence_Channel_path gaussian_gaussian.layer8_out_U");
                                $fdisplay(fp, "Dependence_Channel_status EMPTY");
                            end
                            else if (~layer8_out_U.if_full_n) begin
                                $display("//      Blocked by full output FIFO 'gaussian_gaussian.layer8_out_U' read by process 'gaussian_gaussian.relu_array_ap_fixed_8u_array_ap_ufixed_8_0_4_0_0_8u_relu_config8_U0'");
                                $fdisplay(fp, "Dependence_Channel_path gaussian_gaussian.layer8_out_U");
                                $fdisplay(fp, "Dependence_Channel_status FULL");
                            end
                        end
// for dep channel 'gaussian_gaussian.start_for_pooling2d_cl_array_ap_ufixed_8u_array_ap_ufixed_8_0_4_0_0_8u_configKfY_U' info is :
// blk sig is {{~gaussian_gaussian_inst.start_for_pooling2d_cl_array_ap_ufixed_8u_array_ap_ufixed_8_0_4_0_0_8u_configKfY_U.if_empty_n & gaussian_gaussian_inst.pooling2d_cl_array_ap_ufixed_8u_array_ap_ufixed_8_0_4_0_0_8u_config9_U0.ap_idle & ~gaussian_gaussian_inst.start_for_pooling2d_cl_array_ap_ufixed_8u_array_ap_ufixed_8_0_4_0_0_8u_configKfY_U.if_write} start_FIFO}
                        if ((~start_for_pooling2d_cl_array_ap_ufixed_8u_array_ap_ufixed_8_0_4_0_0_8u_configKfY_U.if_empty_n & pooling2d_cl_array_ap_ufixed_8u_array_ap_ufixed_8_0_4_0_0_8u_config9_U0.ap_idle & ~start_for_pooling2d_cl_array_ap_ufixed_8u_array_ap_ufixed_8_0_4_0_0_8u_configKfY_U.if_write)) begin
                            $display("//      Blocked by missing 'ap_start' from start propagation FIFO 'gaussian_gaussian.start_for_pooling2d_cl_array_ap_ufixed_8u_array_ap_ufixed_8_0_4_0_0_8u_configKfY_U' written by process 'gaussian_gaussian.relu_array_ap_fixed_8u_array_ap_ufixed_8_0_4_0_0_8u_relu_config8_U0',");
                        end
                    end
                    8: begin //  for dep proc 'gaussian_gaussian.zeropad2d_cl_array_array_ap_ufixed_8_0_4_0_0_8u_config36_U0'
// for dep channel 'gaussian_gaussian.layer9_out_U' info is :
// blk sig is {~gaussian_gaussian_inst.pooling2d_cl_array_ap_ufixed_8u_array_ap_ufixed_8_0_4_0_0_8u_config9_U0.layer9_out_blk_n data_FIFO}
                        if ((~pooling2d_cl_array_ap_ufixed_8u_array_ap_ufixed_8_0_4_0_0_8u_config9_U0.layer9_out_blk_n)) begin
                            if (~layer9_out_U.if_empty_n) begin
                                $display("//      Blocked by empty input FIFO 'gaussian_gaussian.layer9_out_U' written by process 'gaussian_gaussian.zeropad2d_cl_array_array_ap_ufixed_8_0_4_0_0_8u_config36_U0'");
                                $fdisplay(fp, "Dependence_Channel_path gaussian_gaussian.layer9_out_U");
                                $fdisplay(fp, "Dependence_Channel_status EMPTY");
                            end
                            else if (~layer9_out_U.if_full_n) begin
                                $display("//      Blocked by full output FIFO 'gaussian_gaussian.layer9_out_U' read by process 'gaussian_gaussian.zeropad2d_cl_array_array_ap_ufixed_8_0_4_0_0_8u_config36_U0'");
                                $fdisplay(fp, "Dependence_Channel_path gaussian_gaussian.layer9_out_U");
                                $fdisplay(fp, "Dependence_Channel_status FULL");
                            end
                        end
// for dep channel 'gaussian_gaussian.start_for_zeropad2d_cl_array_array_ap_ufixed_8_0_4_0_0_8u_config36_U0_U' info is :
// blk sig is {{~gaussian_gaussian_inst.start_for_zeropad2d_cl_array_array_ap_ufixed_8_0_4_0_0_8u_config36_U0_U.if_full_n & gaussian_gaussian_inst.pooling2d_cl_array_ap_ufixed_8u_array_ap_ufixed_8_0_4_0_0_8u_config9_U0.ap_start & ~gaussian_gaussian_inst.pooling2d_cl_array_ap_ufixed_8u_array_ap_ufixed_8_0_4_0_0_8u_config9_U0.real_start & (trans_in_cnt_7 == trans_out_cnt_7) & ~gaussian_gaussian_inst.start_for_zeropad2d_cl_array_array_ap_ufixed_8_0_4_0_0_8u_config36_U0_U.if_read} start_FIFO}
                        if ((~start_for_zeropad2d_cl_array_array_ap_ufixed_8_0_4_0_0_8u_config36_U0_U.if_full_n & pooling2d_cl_array_ap_ufixed_8u_array_ap_ufixed_8_0_4_0_0_8u_config9_U0.ap_start & ~pooling2d_cl_array_ap_ufixed_8u_array_ap_ufixed_8_0_4_0_0_8u_config9_U0.real_start & (trans_in_cnt_7 == trans_out_cnt_7) & ~start_for_zeropad2d_cl_array_array_ap_ufixed_8_0_4_0_0_8u_config36_U0_U.if_read)) begin
                            $display("//      Blocked by full output start propagation FIFO 'gaussian_gaussian.start_for_zeropad2d_cl_array_array_ap_ufixed_8_0_4_0_0_8u_config36_U0_U' read by process 'gaussian_gaussian.zeropad2d_cl_array_array_ap_ufixed_8_0_4_0_0_8u_config36_U0',");
                        end
                    end
                    endcase
                end
                8 : begin // for proc 'gaussian_gaussian.zeropad2d_cl_array_array_ap_ufixed_8_0_4_0_0_8u_config36_U0'
                    case(index2)
                    7: begin //  for dep proc 'gaussian_gaussian.pooling2d_cl_array_ap_ufixed_8u_array_ap_ufixed_8_0_4_0_0_8u_config9_U0'
// for dep channel 'gaussian_gaussian.layer9_out_U' info is :
// blk sig is {~gaussian_gaussian_inst.zeropad2d_cl_array_array_ap_ufixed_8_0_4_0_0_8u_config36_U0.grp_zeropad2d_cl_array_array_ap_ufixed_8_0_4_0_0_8u_config36_Pipeline_PadMain_fu_28.layer9_out_blk_n data_FIFO}
                        if ((~zeropad2d_cl_array_array_ap_ufixed_8_0_4_0_0_8u_config36_U0.grp_zeropad2d_cl_array_array_ap_ufixed_8_0_4_0_0_8u_config36_Pipeline_PadMain_fu_28.layer9_out_blk_n)) begin
                            if (~layer9_out_U.if_empty_n) begin
                                $display("//      Blocked by empty input FIFO 'gaussian_gaussian.layer9_out_U' written by process 'gaussian_gaussian.pooling2d_cl_array_ap_ufixed_8u_array_ap_ufixed_8_0_4_0_0_8u_config9_U0'");
                                $fdisplay(fp, "Dependence_Channel_path gaussian_gaussian.layer9_out_U");
                                $fdisplay(fp, "Dependence_Channel_status EMPTY");
                            end
                            else if (~layer9_out_U.if_full_n) begin
                                $display("//      Blocked by full output FIFO 'gaussian_gaussian.layer9_out_U' read by process 'gaussian_gaussian.pooling2d_cl_array_ap_ufixed_8u_array_ap_ufixed_8_0_4_0_0_8u_config9_U0'");
                                $fdisplay(fp, "Dependence_Channel_path gaussian_gaussian.layer9_out_U");
                                $fdisplay(fp, "Dependence_Channel_status FULL");
                            end
                        end
// for dep channel 'gaussian_gaussian.start_for_zeropad2d_cl_array_array_ap_ufixed_8_0_4_0_0_8u_config36_U0_U' info is :
// blk sig is {{~gaussian_gaussian_inst.start_for_zeropad2d_cl_array_array_ap_ufixed_8_0_4_0_0_8u_config36_U0_U.if_empty_n & gaussian_gaussian_inst.zeropad2d_cl_array_array_ap_ufixed_8_0_4_0_0_8u_config36_U0.ap_idle & ~gaussian_gaussian_inst.start_for_zeropad2d_cl_array_array_ap_ufixed_8_0_4_0_0_8u_config36_U0_U.if_write} start_FIFO}
                        if ((~start_for_zeropad2d_cl_array_array_ap_ufixed_8_0_4_0_0_8u_config36_U0_U.if_empty_n & zeropad2d_cl_array_array_ap_ufixed_8_0_4_0_0_8u_config36_U0.ap_idle & ~start_for_zeropad2d_cl_array_array_ap_ufixed_8_0_4_0_0_8u_config36_U0_U.if_write)) begin
                            $display("//      Blocked by missing 'ap_start' from start propagation FIFO 'gaussian_gaussian.start_for_zeropad2d_cl_array_array_ap_ufixed_8_0_4_0_0_8u_config36_U0_U' written by process 'gaussian_gaussian.pooling2d_cl_array_ap_ufixed_8u_array_ap_ufixed_8_0_4_0_0_8u_config9_U0',");
                        end
                    end
                    9: begin //  for dep proc 'gaussian_gaussian.conv_2d_cl_array_ap_ufixed_8u_array_ap_fixed_24_9_5_3_0_8u_config10_U0'
// for dep channel 'gaussian_gaussian.layer36_out_U' info is :
// blk sig is {~gaussian_gaussian_inst.zeropad2d_cl_array_array_ap_ufixed_8_0_4_0_0_8u_config36_U0.grp_zeropad2d_cl_array_array_ap_ufixed_8_0_4_0_0_8u_config36_Pipeline_PadTopWidth_fu_22.layer36_out_blk_n data_FIFO}
                        if ((~zeropad2d_cl_array_array_ap_ufixed_8_0_4_0_0_8u_config36_U0.grp_zeropad2d_cl_array_array_ap_ufixed_8_0_4_0_0_8u_config36_Pipeline_PadTopWidth_fu_22.layer36_out_blk_n)) begin
                            if (~layer36_out_U.if_empty_n) begin
                                $display("//      Blocked by empty input FIFO 'gaussian_gaussian.layer36_out_U' written by process 'gaussian_gaussian.conv_2d_cl_array_ap_ufixed_8u_array_ap_fixed_24_9_5_3_0_8u_config10_U0'");
                                $fdisplay(fp, "Dependence_Channel_path gaussian_gaussian.layer36_out_U");
                                $fdisplay(fp, "Dependence_Channel_status EMPTY");
                            end
                            else if (~layer36_out_U.if_full_n) begin
                                $display("//      Blocked by full output FIFO 'gaussian_gaussian.layer36_out_U' read by process 'gaussian_gaussian.conv_2d_cl_array_ap_ufixed_8u_array_ap_fixed_24_9_5_3_0_8u_config10_U0'");
                                $fdisplay(fp, "Dependence_Channel_path gaussian_gaussian.layer36_out_U");
                                $fdisplay(fp, "Dependence_Channel_status FULL");
                            end
                        end
// for dep channel 'gaussian_gaussian.start_for_conv_2d_cl_array_ap_ufixed_8u_array_ap_fixed_24_9_5_3_0_8u_config10Lf8_U' info is :
// blk sig is {{~gaussian_gaussian_inst.start_for_conv_2d_cl_array_ap_ufixed_8u_array_ap_fixed_24_9_5_3_0_8u_config10Lf8_U.if_full_n & gaussian_gaussian_inst.zeropad2d_cl_array_array_ap_ufixed_8_0_4_0_0_8u_config36_U0.ap_start & ~gaussian_gaussian_inst.zeropad2d_cl_array_array_ap_ufixed_8_0_4_0_0_8u_config36_U0.real_start & (trans_in_cnt_8 == trans_out_cnt_8) & ~gaussian_gaussian_inst.start_for_conv_2d_cl_array_ap_ufixed_8u_array_ap_fixed_24_9_5_3_0_8u_config10Lf8_U.if_read} start_FIFO}
                        if ((~start_for_conv_2d_cl_array_ap_ufixed_8u_array_ap_fixed_24_9_5_3_0_8u_config10Lf8_U.if_full_n & zeropad2d_cl_array_array_ap_ufixed_8_0_4_0_0_8u_config36_U0.ap_start & ~zeropad2d_cl_array_array_ap_ufixed_8_0_4_0_0_8u_config36_U0.real_start & (trans_in_cnt_8 == trans_out_cnt_8) & ~start_for_conv_2d_cl_array_ap_ufixed_8u_array_ap_fixed_24_9_5_3_0_8u_config10Lf8_U.if_read)) begin
                            $display("//      Blocked by full output start propagation FIFO 'gaussian_gaussian.start_for_conv_2d_cl_array_ap_ufixed_8u_array_ap_fixed_24_9_5_3_0_8u_config10Lf8_U' read by process 'gaussian_gaussian.conv_2d_cl_array_ap_ufixed_8u_array_ap_fixed_24_9_5_3_0_8u_config10_U0',");
                        end
                    end
                    endcase
                end
                9 : begin // for proc 'gaussian_gaussian.conv_2d_cl_array_ap_ufixed_8u_array_ap_fixed_24_9_5_3_0_8u_config10_U0'
                    case(index2)
                    8: begin //  for dep proc 'gaussian_gaussian.zeropad2d_cl_array_array_ap_ufixed_8_0_4_0_0_8u_config36_U0'
// for dep channel 'gaussian_gaussian.layer36_out_U' info is :
// blk sig is {~gaussian_gaussian_inst.conv_2d_cl_array_ap_ufixed_8u_array_ap_fixed_24_9_5_3_0_8u_config10_U0.layer36_out_blk_n data_FIFO}
                        if ((~conv_2d_cl_array_ap_ufixed_8u_array_ap_fixed_24_9_5_3_0_8u_config10_U0.layer36_out_blk_n)) begin
                            if (~layer36_out_U.if_empty_n) begin
                                $display("//      Blocked by empty input FIFO 'gaussian_gaussian.layer36_out_U' written by process 'gaussian_gaussian.zeropad2d_cl_array_array_ap_ufixed_8_0_4_0_0_8u_config36_U0'");
                                $fdisplay(fp, "Dependence_Channel_path gaussian_gaussian.layer36_out_U");
                                $fdisplay(fp, "Dependence_Channel_status EMPTY");
                            end
                            else if (~layer36_out_U.if_full_n) begin
                                $display("//      Blocked by full output FIFO 'gaussian_gaussian.layer36_out_U' read by process 'gaussian_gaussian.zeropad2d_cl_array_array_ap_ufixed_8_0_4_0_0_8u_config36_U0'");
                                $fdisplay(fp, "Dependence_Channel_path gaussian_gaussian.layer36_out_U");
                                $fdisplay(fp, "Dependence_Channel_status FULL");
                            end
                        end
// for dep channel 'gaussian_gaussian.start_for_conv_2d_cl_array_ap_ufixed_8u_array_ap_fixed_24_9_5_3_0_8u_config10Lf8_U' info is :
// blk sig is {{~gaussian_gaussian_inst.start_for_conv_2d_cl_array_ap_ufixed_8u_array_ap_fixed_24_9_5_3_0_8u_config10Lf8_U.if_empty_n & gaussian_gaussian_inst.conv_2d_cl_array_ap_ufixed_8u_array_ap_fixed_24_9_5_3_0_8u_config10_U0.ap_idle & ~gaussian_gaussian_inst.start_for_conv_2d_cl_array_ap_ufixed_8u_array_ap_fixed_24_9_5_3_0_8u_config10Lf8_U.if_write} start_FIFO}
                        if ((~start_for_conv_2d_cl_array_ap_ufixed_8u_array_ap_fixed_24_9_5_3_0_8u_config10Lf8_U.if_empty_n & conv_2d_cl_array_ap_ufixed_8u_array_ap_fixed_24_9_5_3_0_8u_config10_U0.ap_idle & ~start_for_conv_2d_cl_array_ap_ufixed_8u_array_ap_fixed_24_9_5_3_0_8u_config10Lf8_U.if_write)) begin
                            $display("//      Blocked by missing 'ap_start' from start propagation FIFO 'gaussian_gaussian.start_for_conv_2d_cl_array_ap_ufixed_8u_array_ap_fixed_24_9_5_3_0_8u_config10Lf8_U' written by process 'gaussian_gaussian.zeropad2d_cl_array_array_ap_ufixed_8_0_4_0_0_8u_config36_U0',");
                        end
                    end
                    10: begin //  for dep proc 'gaussian_gaussian.relu_array_ap_fixed_8u_array_ap_ufixed_8_0_4_0_0_8u_relu_config12_U0'
// for dep channel 'gaussian_gaussian.layer10_out_U' info is :
// blk sig is {~gaussian_gaussian_inst.conv_2d_cl_array_ap_ufixed_8u_array_ap_fixed_24_9_5_3_0_8u_config10_U0.layer10_out_blk_n data_FIFO} {~gaussian_gaussian_inst.conv_2d_cl_array_ap_ufixed_8u_array_ap_fixed_24_9_5_3_0_8u_config10_U0.grp_compute_output_buffer_2d_array_array_ap_fixed_24_9_5_3_0_8u_config10_s_fu_260.layer10_out_blk_n data_FIFO}
                        if ((~conv_2d_cl_array_ap_ufixed_8u_array_ap_fixed_24_9_5_3_0_8u_config10_U0.layer10_out_blk_n) | (~conv_2d_cl_array_ap_ufixed_8u_array_ap_fixed_24_9_5_3_0_8u_config10_U0.grp_compute_output_buffer_2d_array_array_ap_fixed_24_9_5_3_0_8u_config10_s_fu_260.layer10_out_blk_n)) begin
                            if (~layer10_out_U.if_empty_n) begin
                                $display("//      Blocked by empty input FIFO 'gaussian_gaussian.layer10_out_U' written by process 'gaussian_gaussian.relu_array_ap_fixed_8u_array_ap_ufixed_8_0_4_0_0_8u_relu_config12_U0'");
                                $fdisplay(fp, "Dependence_Channel_path gaussian_gaussian.layer10_out_U");
                                $fdisplay(fp, "Dependence_Channel_status EMPTY");
                            end
                            else if (~layer10_out_U.if_full_n) begin
                                $display("//      Blocked by full output FIFO 'gaussian_gaussian.layer10_out_U' read by process 'gaussian_gaussian.relu_array_ap_fixed_8u_array_ap_ufixed_8_0_4_0_0_8u_relu_config12_U0'");
                                $fdisplay(fp, "Dependence_Channel_path gaussian_gaussian.layer10_out_U");
                                $fdisplay(fp, "Dependence_Channel_status FULL");
                            end
                        end
// for dep channel 'gaussian_gaussian.start_for_relu_array_ap_fixed_8u_array_ap_ufixed_8_0_4_0_0_8u_relu_config12_U0_U' info is :
// blk sig is {{~gaussian_gaussian_inst.start_for_relu_array_ap_fixed_8u_array_ap_ufixed_8_0_4_0_0_8u_relu_config12_U0_U.if_full_n & gaussian_gaussian_inst.conv_2d_cl_array_ap_ufixed_8u_array_ap_fixed_24_9_5_3_0_8u_config10_U0.ap_start & ~gaussian_gaussian_inst.conv_2d_cl_array_ap_ufixed_8u_array_ap_fixed_24_9_5_3_0_8u_config10_U0.real_start & (trans_in_cnt_9 == trans_out_cnt_9) & ~gaussian_gaussian_inst.start_for_relu_array_ap_fixed_8u_array_ap_ufixed_8_0_4_0_0_8u_relu_config12_U0_U.if_read} start_FIFO}
                        if ((~start_for_relu_array_ap_fixed_8u_array_ap_ufixed_8_0_4_0_0_8u_relu_config12_U0_U.if_full_n & conv_2d_cl_array_ap_ufixed_8u_array_ap_fixed_24_9_5_3_0_8u_config10_U0.ap_start & ~conv_2d_cl_array_ap_ufixed_8u_array_ap_fixed_24_9_5_3_0_8u_config10_U0.real_start & (trans_in_cnt_9 == trans_out_cnt_9) & ~start_for_relu_array_ap_fixed_8u_array_ap_ufixed_8_0_4_0_0_8u_relu_config12_U0_U.if_read)) begin
                            $display("//      Blocked by full output start propagation FIFO 'gaussian_gaussian.start_for_relu_array_ap_fixed_8u_array_ap_ufixed_8_0_4_0_0_8u_relu_config12_U0_U' read by process 'gaussian_gaussian.relu_array_ap_fixed_8u_array_ap_ufixed_8_0_4_0_0_8u_relu_config12_U0',");
                        end
                    end
                    endcase
                end
                10 : begin // for proc 'gaussian_gaussian.relu_array_ap_fixed_8u_array_ap_ufixed_8_0_4_0_0_8u_relu_config12_U0'
                    case(index2)
                    9: begin //  for dep proc 'gaussian_gaussian.conv_2d_cl_array_ap_ufixed_8u_array_ap_fixed_24_9_5_3_0_8u_config10_U0'
// for dep channel 'gaussian_gaussian.layer10_out_U' info is :
// blk sig is {~gaussian_gaussian_inst.relu_array_ap_fixed_8u_array_ap_ufixed_8_0_4_0_0_8u_relu_config12_U0.layer10_out_blk_n data_FIFO}
                        if ((~relu_array_ap_fixed_8u_array_ap_ufixed_8_0_4_0_0_8u_relu_config12_U0.layer10_out_blk_n)) begin
                            if (~layer10_out_U.if_empty_n) begin
                                $display("//      Blocked by empty input FIFO 'gaussian_gaussian.layer10_out_U' written by process 'gaussian_gaussian.conv_2d_cl_array_ap_ufixed_8u_array_ap_fixed_24_9_5_3_0_8u_config10_U0'");
                                $fdisplay(fp, "Dependence_Channel_path gaussian_gaussian.layer10_out_U");
                                $fdisplay(fp, "Dependence_Channel_status EMPTY");
                            end
                            else if (~layer10_out_U.if_full_n) begin
                                $display("//      Blocked by full output FIFO 'gaussian_gaussian.layer10_out_U' read by process 'gaussian_gaussian.conv_2d_cl_array_ap_ufixed_8u_array_ap_fixed_24_9_5_3_0_8u_config10_U0'");
                                $fdisplay(fp, "Dependence_Channel_path gaussian_gaussian.layer10_out_U");
                                $fdisplay(fp, "Dependence_Channel_status FULL");
                            end
                        end
// for dep channel 'gaussian_gaussian.start_for_relu_array_ap_fixed_8u_array_ap_ufixed_8_0_4_0_0_8u_relu_config12_U0_U' info is :
// blk sig is {{~gaussian_gaussian_inst.start_for_relu_array_ap_fixed_8u_array_ap_ufixed_8_0_4_0_0_8u_relu_config12_U0_U.if_empty_n & gaussian_gaussian_inst.relu_array_ap_fixed_8u_array_ap_ufixed_8_0_4_0_0_8u_relu_config12_U0.ap_idle & ~gaussian_gaussian_inst.start_for_relu_array_ap_fixed_8u_array_ap_ufixed_8_0_4_0_0_8u_relu_config12_U0_U.if_write} start_FIFO}
                        if ((~start_for_relu_array_ap_fixed_8u_array_ap_ufixed_8_0_4_0_0_8u_relu_config12_U0_U.if_empty_n & relu_array_ap_fixed_8u_array_ap_ufixed_8_0_4_0_0_8u_relu_config12_U0.ap_idle & ~start_for_relu_array_ap_fixed_8u_array_ap_ufixed_8_0_4_0_0_8u_relu_config12_U0_U.if_write)) begin
                            $display("//      Blocked by missing 'ap_start' from start propagation FIFO 'gaussian_gaussian.start_for_relu_array_ap_fixed_8u_array_ap_ufixed_8_0_4_0_0_8u_relu_config12_U0_U' written by process 'gaussian_gaussian.conv_2d_cl_array_ap_ufixed_8u_array_ap_fixed_24_9_5_3_0_8u_config10_U0',");
                        end
                    end
                    11: begin //  for dep proc 'gaussian_gaussian.pooling2d_cl_array_array_ap_ufixed_8_0_4_0_0_8u_config13_U0'
// for dep channel 'gaussian_gaussian.layer12_out_U' info is :
// blk sig is {~gaussian_gaussian_inst.relu_array_ap_fixed_8u_array_ap_ufixed_8_0_4_0_0_8u_relu_config12_U0.layer12_out_blk_n data_FIFO}
                        if ((~relu_array_ap_fixed_8u_array_ap_ufixed_8_0_4_0_0_8u_relu_config12_U0.layer12_out_blk_n)) begin
                            if (~layer12_out_U.if_empty_n) begin
                                $display("//      Blocked by empty input FIFO 'gaussian_gaussian.layer12_out_U' written by process 'gaussian_gaussian.pooling2d_cl_array_array_ap_ufixed_8_0_4_0_0_8u_config13_U0'");
                                $fdisplay(fp, "Dependence_Channel_path gaussian_gaussian.layer12_out_U");
                                $fdisplay(fp, "Dependence_Channel_status EMPTY");
                            end
                            else if (~layer12_out_U.if_full_n) begin
                                $display("//      Blocked by full output FIFO 'gaussian_gaussian.layer12_out_U' read by process 'gaussian_gaussian.pooling2d_cl_array_array_ap_ufixed_8_0_4_0_0_8u_config13_U0'");
                                $fdisplay(fp, "Dependence_Channel_path gaussian_gaussian.layer12_out_U");
                                $fdisplay(fp, "Dependence_Channel_status FULL");
                            end
                        end
// for dep channel 'gaussian_gaussian.start_for_pooling2d_cl_array_array_ap_ufixed_8_0_4_0_0_8u_config13_U0_U' info is :
// blk sig is {{~gaussian_gaussian_inst.start_for_pooling2d_cl_array_array_ap_ufixed_8_0_4_0_0_8u_config13_U0_U.if_full_n & gaussian_gaussian_inst.relu_array_ap_fixed_8u_array_ap_ufixed_8_0_4_0_0_8u_relu_config12_U0.ap_start & ~gaussian_gaussian_inst.relu_array_ap_fixed_8u_array_ap_ufixed_8_0_4_0_0_8u_relu_config12_U0.real_start & (trans_in_cnt_10 == trans_out_cnt_10) & ~gaussian_gaussian_inst.start_for_pooling2d_cl_array_array_ap_ufixed_8_0_4_0_0_8u_config13_U0_U.if_read} start_FIFO}
                        if ((~start_for_pooling2d_cl_array_array_ap_ufixed_8_0_4_0_0_8u_config13_U0_U.if_full_n & relu_array_ap_fixed_8u_array_ap_ufixed_8_0_4_0_0_8u_relu_config12_U0.ap_start & ~relu_array_ap_fixed_8u_array_ap_ufixed_8_0_4_0_0_8u_relu_config12_U0.real_start & (trans_in_cnt_10 == trans_out_cnt_10) & ~start_for_pooling2d_cl_array_array_ap_ufixed_8_0_4_0_0_8u_config13_U0_U.if_read)) begin
                            $display("//      Blocked by full output start propagation FIFO 'gaussian_gaussian.start_for_pooling2d_cl_array_array_ap_ufixed_8_0_4_0_0_8u_config13_U0_U' read by process 'gaussian_gaussian.pooling2d_cl_array_array_ap_ufixed_8_0_4_0_0_8u_config13_U0',");
                        end
                    end
                    endcase
                end
                11 : begin // for proc 'gaussian_gaussian.pooling2d_cl_array_array_ap_ufixed_8_0_4_0_0_8u_config13_U0'
                    case(index2)
                    10: begin //  for dep proc 'gaussian_gaussian.relu_array_ap_fixed_8u_array_ap_ufixed_8_0_4_0_0_8u_relu_config12_U0'
// for dep channel 'gaussian_gaussian.layer12_out_U' info is :
// blk sig is {~gaussian_gaussian_inst.pooling2d_cl_array_array_ap_ufixed_8_0_4_0_0_8u_config13_U0.layer12_out_blk_n data_FIFO}
                        if ((~pooling2d_cl_array_array_ap_ufixed_8_0_4_0_0_8u_config13_U0.layer12_out_blk_n)) begin
                            if (~layer12_out_U.if_empty_n) begin
                                $display("//      Blocked by empty input FIFO 'gaussian_gaussian.layer12_out_U' written by process 'gaussian_gaussian.relu_array_ap_fixed_8u_array_ap_ufixed_8_0_4_0_0_8u_relu_config12_U0'");
                                $fdisplay(fp, "Dependence_Channel_path gaussian_gaussian.layer12_out_U");
                                $fdisplay(fp, "Dependence_Channel_status EMPTY");
                            end
                            else if (~layer12_out_U.if_full_n) begin
                                $display("//      Blocked by full output FIFO 'gaussian_gaussian.layer12_out_U' read by process 'gaussian_gaussian.relu_array_ap_fixed_8u_array_ap_ufixed_8_0_4_0_0_8u_relu_config12_U0'");
                                $fdisplay(fp, "Dependence_Channel_path gaussian_gaussian.layer12_out_U");
                                $fdisplay(fp, "Dependence_Channel_status FULL");
                            end
                        end
// for dep channel 'gaussian_gaussian.start_for_pooling2d_cl_array_array_ap_ufixed_8_0_4_0_0_8u_config13_U0_U' info is :
// blk sig is {{~gaussian_gaussian_inst.start_for_pooling2d_cl_array_array_ap_ufixed_8_0_4_0_0_8u_config13_U0_U.if_empty_n & gaussian_gaussian_inst.pooling2d_cl_array_array_ap_ufixed_8_0_4_0_0_8u_config13_U0.ap_idle & ~gaussian_gaussian_inst.start_for_pooling2d_cl_array_array_ap_ufixed_8_0_4_0_0_8u_config13_U0_U.if_write} start_FIFO}
                        if ((~start_for_pooling2d_cl_array_array_ap_ufixed_8_0_4_0_0_8u_config13_U0_U.if_empty_n & pooling2d_cl_array_array_ap_ufixed_8_0_4_0_0_8u_config13_U0.ap_idle & ~start_for_pooling2d_cl_array_array_ap_ufixed_8_0_4_0_0_8u_config13_U0_U.if_write)) begin
                            $display("//      Blocked by missing 'ap_start' from start propagation FIFO 'gaussian_gaussian.start_for_pooling2d_cl_array_array_ap_ufixed_8_0_4_0_0_8u_config13_U0_U' written by process 'gaussian_gaussian.relu_array_ap_fixed_8u_array_ap_ufixed_8_0_4_0_0_8u_relu_config12_U0',");
                        end
                    end
                    12: begin //  for dep proc 'gaussian_gaussian.global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config14_U0'
// for dep channel 'gaussian_gaussian.layer13_out_U' info is :
// blk sig is {~gaussian_gaussian_inst.pooling2d_cl_array_array_ap_ufixed_8_0_4_0_0_8u_config13_U0.layer13_out_blk_n data_FIFO}
                        if ((~pooling2d_cl_array_array_ap_ufixed_8_0_4_0_0_8u_config13_U0.layer13_out_blk_n)) begin
                            if (~layer13_out_U.if_empty_n) begin
                                $display("//      Blocked by empty input FIFO 'gaussian_gaussian.layer13_out_U' written by process 'gaussian_gaussian.global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config14_U0'");
                                $fdisplay(fp, "Dependence_Channel_path gaussian_gaussian.layer13_out_U");
                                $fdisplay(fp, "Dependence_Channel_status EMPTY");
                            end
                            else if (~layer13_out_U.if_full_n) begin
                                $display("//      Blocked by full output FIFO 'gaussian_gaussian.layer13_out_U' read by process 'gaussian_gaussian.global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config14_U0'");
                                $fdisplay(fp, "Dependence_Channel_path gaussian_gaussian.layer13_out_U");
                                $fdisplay(fp, "Dependence_Channel_status FULL");
                            end
                        end
// for dep channel 'gaussian_gaussian.start_for_global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config14_U0_U' info is :
// blk sig is {{~gaussian_gaussian_inst.start_for_global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config14_U0_U.if_full_n & gaussian_gaussian_inst.pooling2d_cl_array_array_ap_ufixed_8_0_4_0_0_8u_config13_U0.ap_start & ~gaussian_gaussian_inst.pooling2d_cl_array_array_ap_ufixed_8_0_4_0_0_8u_config13_U0.real_start & (trans_in_cnt_11 == trans_out_cnt_11) & ~gaussian_gaussian_inst.start_for_global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config14_U0_U.if_read} start_FIFO}
                        if ((~start_for_global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config14_U0_U.if_full_n & pooling2d_cl_array_array_ap_ufixed_8_0_4_0_0_8u_config13_U0.ap_start & ~pooling2d_cl_array_array_ap_ufixed_8_0_4_0_0_8u_config13_U0.real_start & (trans_in_cnt_11 == trans_out_cnt_11) & ~start_for_global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config14_U0_U.if_read)) begin
                            $display("//      Blocked by full output start propagation FIFO 'gaussian_gaussian.start_for_global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config14_U0_U' read by process 'gaussian_gaussian.global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config14_U0',");
                        end
                    end
                    endcase
                end
                12 : begin // for proc 'gaussian_gaussian.global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config14_U0'
                    case(index2)
                    11: begin //  for dep proc 'gaussian_gaussian.pooling2d_cl_array_array_ap_ufixed_8_0_4_0_0_8u_config13_U0'
// for dep channel 'gaussian_gaussian.layer13_out_U' info is :
// blk sig is {~gaussian_gaussian_inst.global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config14_U0.grp_global_pooling2d_cl_Pipeline_ReadInputHeight_ReadInputWidth_fu_71.layer13_out_blk_n data_FIFO}
                        if ((~global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config14_U0.grp_global_pooling2d_cl_Pipeline_ReadInputHeight_ReadInputWidth_fu_71.layer13_out_blk_n)) begin
                            if (~layer13_out_U.if_empty_n) begin
                                $display("//      Blocked by empty input FIFO 'gaussian_gaussian.layer13_out_U' written by process 'gaussian_gaussian.pooling2d_cl_array_array_ap_ufixed_8_0_4_0_0_8u_config13_U0'");
                                $fdisplay(fp, "Dependence_Channel_path gaussian_gaussian.layer13_out_U");
                                $fdisplay(fp, "Dependence_Channel_status EMPTY");
                            end
                            else if (~layer13_out_U.if_full_n) begin
                                $display("//      Blocked by full output FIFO 'gaussian_gaussian.layer13_out_U' read by process 'gaussian_gaussian.pooling2d_cl_array_array_ap_ufixed_8_0_4_0_0_8u_config13_U0'");
                                $fdisplay(fp, "Dependence_Channel_path gaussian_gaussian.layer13_out_U");
                                $fdisplay(fp, "Dependence_Channel_status FULL");
                            end
                        end
// for dep channel 'gaussian_gaussian.start_for_global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config14_U0_U' info is :
// blk sig is {{~gaussian_gaussian_inst.start_for_global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config14_U0_U.if_empty_n & gaussian_gaussian_inst.global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config14_U0.ap_idle & ~gaussian_gaussian_inst.start_for_global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config14_U0_U.if_write} start_FIFO}
                        if ((~start_for_global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config14_U0_U.if_empty_n & global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config14_U0.ap_idle & ~start_for_global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config14_U0_U.if_write)) begin
                            $display("//      Blocked by missing 'ap_start' from start propagation FIFO 'gaussian_gaussian.start_for_global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config14_U0_U' written by process 'gaussian_gaussian.pooling2d_cl_array_array_ap_ufixed_8_0_4_0_0_8u_config13_U0',");
                        end
                    end
                    13: begin //  for dep proc 'gaussian_gaussian.dense_array_ap_fixed_8u_array_ap_fixed_28_11_5_3_0_16u_config15_U0'
// for dep channel 'gaussian_gaussian.layer14_out_U' info is :
// blk sig is {~gaussian_gaussian_inst.global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config14_U0.layer14_out_blk_n data_FIFO}
                        if ((~global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config14_U0.layer14_out_blk_n)) begin
                            if (~layer14_out_U.if_empty_n) begin
                                $display("//      Blocked by empty input FIFO 'gaussian_gaussian.layer14_out_U' written by process 'gaussian_gaussian.dense_array_ap_fixed_8u_array_ap_fixed_28_11_5_3_0_16u_config15_U0'");
                                $fdisplay(fp, "Dependence_Channel_path gaussian_gaussian.layer14_out_U");
                                $fdisplay(fp, "Dependence_Channel_status EMPTY");
                            end
                            else if (~layer14_out_U.if_full_n) begin
                                $display("//      Blocked by full output FIFO 'gaussian_gaussian.layer14_out_U' read by process 'gaussian_gaussian.dense_array_ap_fixed_8u_array_ap_fixed_28_11_5_3_0_16u_config15_U0'");
                                $fdisplay(fp, "Dependence_Channel_path gaussian_gaussian.layer14_out_U");
                                $fdisplay(fp, "Dependence_Channel_status FULL");
                            end
                        end
// for dep channel 'gaussian_gaussian.start_for_dense_array_ap_fixed_8u_array_ap_fixed_28_11_5_3_0_16u_config15_U0_U' info is :
// blk sig is {{~gaussian_gaussian_inst.start_for_dense_array_ap_fixed_8u_array_ap_fixed_28_11_5_3_0_16u_config15_U0_U.if_full_n & gaussian_gaussian_inst.global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config14_U0.ap_start & ~gaussian_gaussian_inst.global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config14_U0.real_start & (trans_in_cnt_12 == trans_out_cnt_12) & ~gaussian_gaussian_inst.start_for_dense_array_ap_fixed_8u_array_ap_fixed_28_11_5_3_0_16u_config15_U0_U.if_read} start_FIFO}
                        if ((~start_for_dense_array_ap_fixed_8u_array_ap_fixed_28_11_5_3_0_16u_config15_U0_U.if_full_n & global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config14_U0.ap_start & ~global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config14_U0.real_start & (trans_in_cnt_12 == trans_out_cnt_12) & ~start_for_dense_array_ap_fixed_8u_array_ap_fixed_28_11_5_3_0_16u_config15_U0_U.if_read)) begin
                            $display("//      Blocked by full output start propagation FIFO 'gaussian_gaussian.start_for_dense_array_ap_fixed_8u_array_ap_fixed_28_11_5_3_0_16u_config15_U0_U' read by process 'gaussian_gaussian.dense_array_ap_fixed_8u_array_ap_fixed_28_11_5_3_0_16u_config15_U0',");
                        end
                    end
                    endcase
                end
                13 : begin // for proc 'gaussian_gaussian.dense_array_ap_fixed_8u_array_ap_fixed_28_11_5_3_0_16u_config15_U0'
                    case(index2)
                    12: begin //  for dep proc 'gaussian_gaussian.global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config14_U0'
// for dep channel 'gaussian_gaussian.layer14_out_U' info is :
// blk sig is {~gaussian_gaussian_inst.dense_array_ap_fixed_8u_array_ap_fixed_28_11_5_3_0_16u_config15_U0.layer14_out_blk_n data_FIFO}
                        if ((~dense_array_ap_fixed_8u_array_ap_fixed_28_11_5_3_0_16u_config15_U0.layer14_out_blk_n)) begin
                            if (~layer14_out_U.if_empty_n) begin
                                $display("//      Blocked by empty input FIFO 'gaussian_gaussian.layer14_out_U' written by process 'gaussian_gaussian.global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config14_U0'");
                                $fdisplay(fp, "Dependence_Channel_path gaussian_gaussian.layer14_out_U");
                                $fdisplay(fp, "Dependence_Channel_status EMPTY");
                            end
                            else if (~layer14_out_U.if_full_n) begin
                                $display("//      Blocked by full output FIFO 'gaussian_gaussian.layer14_out_U' read by process 'gaussian_gaussian.global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config14_U0'");
                                $fdisplay(fp, "Dependence_Channel_path gaussian_gaussian.layer14_out_U");
                                $fdisplay(fp, "Dependence_Channel_status FULL");
                            end
                        end
// for dep channel 'gaussian_gaussian.start_for_dense_array_ap_fixed_8u_array_ap_fixed_28_11_5_3_0_16u_config15_U0_U' info is :
// blk sig is {{~gaussian_gaussian_inst.start_for_dense_array_ap_fixed_8u_array_ap_fixed_28_11_5_3_0_16u_config15_U0_U.if_empty_n & gaussian_gaussian_inst.dense_array_ap_fixed_8u_array_ap_fixed_28_11_5_3_0_16u_config15_U0.ap_idle & ~gaussian_gaussian_inst.start_for_dense_array_ap_fixed_8u_array_ap_fixed_28_11_5_3_0_16u_config15_U0_U.if_write} start_FIFO}
                        if ((~start_for_dense_array_ap_fixed_8u_array_ap_fixed_28_11_5_3_0_16u_config15_U0_U.if_empty_n & dense_array_ap_fixed_8u_array_ap_fixed_28_11_5_3_0_16u_config15_U0.ap_idle & ~start_for_dense_array_ap_fixed_8u_array_ap_fixed_28_11_5_3_0_16u_config15_U0_U.if_write)) begin
                            $display("//      Blocked by missing 'ap_start' from start propagation FIFO 'gaussian_gaussian.start_for_dense_array_ap_fixed_8u_array_ap_fixed_28_11_5_3_0_16u_config15_U0_U' written by process 'gaussian_gaussian.global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config14_U0',");
                        end
                    end
                    14: begin //  for dep proc 'gaussian_gaussian.relu_array_ap_fixed_16u_array_ap_ufixed_8_0_4_0_0_16u_relu_config17_U0'
// for dep channel 'gaussian_gaussian.layer15_out_U' info is :
// blk sig is {~gaussian_gaussian_inst.dense_array_ap_fixed_8u_array_ap_fixed_28_11_5_3_0_16u_config15_U0.layer15_out_blk_n data_FIFO}
                        if ((~dense_array_ap_fixed_8u_array_ap_fixed_28_11_5_3_0_16u_config15_U0.layer15_out_blk_n)) begin
                            if (~layer15_out_U.if_empty_n) begin
                                $display("//      Blocked by empty input FIFO 'gaussian_gaussian.layer15_out_U' written by process 'gaussian_gaussian.relu_array_ap_fixed_16u_array_ap_ufixed_8_0_4_0_0_16u_relu_config17_U0'");
                                $fdisplay(fp, "Dependence_Channel_path gaussian_gaussian.layer15_out_U");
                                $fdisplay(fp, "Dependence_Channel_status EMPTY");
                            end
                            else if (~layer15_out_U.if_full_n) begin
                                $display("//      Blocked by full output FIFO 'gaussian_gaussian.layer15_out_U' read by process 'gaussian_gaussian.relu_array_ap_fixed_16u_array_ap_ufixed_8_0_4_0_0_16u_relu_config17_U0'");
                                $fdisplay(fp, "Dependence_Channel_path gaussian_gaussian.layer15_out_U");
                                $fdisplay(fp, "Dependence_Channel_status FULL");
                            end
                        end
// for dep channel 'gaussian_gaussian.start_for_relu_array_ap_fixed_16u_array_ap_ufixed_8_0_4_0_0_16u_relu_config17Mgi_U' info is :
// blk sig is {{~gaussian_gaussian_inst.start_for_relu_array_ap_fixed_16u_array_ap_ufixed_8_0_4_0_0_16u_relu_config17Mgi_U.if_full_n & gaussian_gaussian_inst.dense_array_ap_fixed_8u_array_ap_fixed_28_11_5_3_0_16u_config15_U0.ap_start & ~gaussian_gaussian_inst.dense_array_ap_fixed_8u_array_ap_fixed_28_11_5_3_0_16u_config15_U0.real_start & (trans_in_cnt_13 == trans_out_cnt_13) & ~gaussian_gaussian_inst.start_for_relu_array_ap_fixed_16u_array_ap_ufixed_8_0_4_0_0_16u_relu_config17Mgi_U.if_read} start_FIFO}
                        if ((~start_for_relu_array_ap_fixed_16u_array_ap_ufixed_8_0_4_0_0_16u_relu_config17Mgi_U.if_full_n & dense_array_ap_fixed_8u_array_ap_fixed_28_11_5_3_0_16u_config15_U0.ap_start & ~dense_array_ap_fixed_8u_array_ap_fixed_28_11_5_3_0_16u_config15_U0.real_start & (trans_in_cnt_13 == trans_out_cnt_13) & ~start_for_relu_array_ap_fixed_16u_array_ap_ufixed_8_0_4_0_0_16u_relu_config17Mgi_U.if_read)) begin
                            $display("//      Blocked by full output start propagation FIFO 'gaussian_gaussian.start_for_relu_array_ap_fixed_16u_array_ap_ufixed_8_0_4_0_0_16u_relu_config17Mgi_U' read by process 'gaussian_gaussian.relu_array_ap_fixed_16u_array_ap_ufixed_8_0_4_0_0_16u_relu_config17_U0',");
                        end
                    end
                    endcase
                end
                14 : begin // for proc 'gaussian_gaussian.relu_array_ap_fixed_16u_array_ap_ufixed_8_0_4_0_0_16u_relu_config17_U0'
                    case(index2)
                    13: begin //  for dep proc 'gaussian_gaussian.dense_array_ap_fixed_8u_array_ap_fixed_28_11_5_3_0_16u_config15_U0'
// for dep channel 'gaussian_gaussian.layer15_out_U' info is :
// blk sig is {~gaussian_gaussian_inst.relu_array_ap_fixed_16u_array_ap_ufixed_8_0_4_0_0_16u_relu_config17_U0.layer15_out_blk_n data_FIFO}
                        if ((~relu_array_ap_fixed_16u_array_ap_ufixed_8_0_4_0_0_16u_relu_config17_U0.layer15_out_blk_n)) begin
                            if (~layer15_out_U.if_empty_n) begin
                                $display("//      Blocked by empty input FIFO 'gaussian_gaussian.layer15_out_U' written by process 'gaussian_gaussian.dense_array_ap_fixed_8u_array_ap_fixed_28_11_5_3_0_16u_config15_U0'");
                                $fdisplay(fp, "Dependence_Channel_path gaussian_gaussian.layer15_out_U");
                                $fdisplay(fp, "Dependence_Channel_status EMPTY");
                            end
                            else if (~layer15_out_U.if_full_n) begin
                                $display("//      Blocked by full output FIFO 'gaussian_gaussian.layer15_out_U' read by process 'gaussian_gaussian.dense_array_ap_fixed_8u_array_ap_fixed_28_11_5_3_0_16u_config15_U0'");
                                $fdisplay(fp, "Dependence_Channel_path gaussian_gaussian.layer15_out_U");
                                $fdisplay(fp, "Dependence_Channel_status FULL");
                            end
                        end
// for dep channel 'gaussian_gaussian.start_for_relu_array_ap_fixed_16u_array_ap_ufixed_8_0_4_0_0_16u_relu_config17Mgi_U' info is :
// blk sig is {{~gaussian_gaussian_inst.start_for_relu_array_ap_fixed_16u_array_ap_ufixed_8_0_4_0_0_16u_relu_config17Mgi_U.if_empty_n & gaussian_gaussian_inst.relu_array_ap_fixed_16u_array_ap_ufixed_8_0_4_0_0_16u_relu_config17_U0.ap_idle & ~gaussian_gaussian_inst.start_for_relu_array_ap_fixed_16u_array_ap_ufixed_8_0_4_0_0_16u_relu_config17Mgi_U.if_write} start_FIFO}
                        if ((~start_for_relu_array_ap_fixed_16u_array_ap_ufixed_8_0_4_0_0_16u_relu_config17Mgi_U.if_empty_n & relu_array_ap_fixed_16u_array_ap_ufixed_8_0_4_0_0_16u_relu_config17_U0.ap_idle & ~start_for_relu_array_ap_fixed_16u_array_ap_ufixed_8_0_4_0_0_16u_relu_config17Mgi_U.if_write)) begin
                            $display("//      Blocked by missing 'ap_start' from start propagation FIFO 'gaussian_gaussian.start_for_relu_array_ap_fixed_16u_array_ap_ufixed_8_0_4_0_0_16u_relu_config17Mgi_U' written by process 'gaussian_gaussian.dense_array_ap_fixed_8u_array_ap_fixed_28_11_5_3_0_16u_config15_U0',");
                        end
                    end
                    15: begin //  for dep proc 'gaussian_gaussian.clone_stream_array_ap_ufixed_16u_array_ap_ufixed_8_0_4_0_0_16u_16_U0'
// for dep channel 'gaussian_gaussian.layer17_out_U' info is :
// blk sig is {~gaussian_gaussian_inst.relu_array_ap_fixed_16u_array_ap_ufixed_8_0_4_0_0_16u_relu_config17_U0.layer17_out_blk_n data_FIFO}
                        if ((~relu_array_ap_fixed_16u_array_ap_ufixed_8_0_4_0_0_16u_relu_config17_U0.layer17_out_blk_n)) begin
                            if (~layer17_out_U.if_empty_n) begin
                                $display("//      Blocked by empty input FIFO 'gaussian_gaussian.layer17_out_U' written by process 'gaussian_gaussian.clone_stream_array_ap_ufixed_16u_array_ap_ufixed_8_0_4_0_0_16u_16_U0'");
                                $fdisplay(fp, "Dependence_Channel_path gaussian_gaussian.layer17_out_U");
                                $fdisplay(fp, "Dependence_Channel_status EMPTY");
                            end
                            else if (~layer17_out_U.if_full_n) begin
                                $display("//      Blocked by full output FIFO 'gaussian_gaussian.layer17_out_U' read by process 'gaussian_gaussian.clone_stream_array_ap_ufixed_16u_array_ap_ufixed_8_0_4_0_0_16u_16_U0'");
                                $fdisplay(fp, "Dependence_Channel_path gaussian_gaussian.layer17_out_U");
                                $fdisplay(fp, "Dependence_Channel_status FULL");
                            end
                        end
// for dep channel 'gaussian_gaussian.start_for_clone_stream_array_ap_ufixed_16u_array_ap_ufixed_8_0_4_0_0_16u_16_U0_U' info is :
// blk sig is {{~gaussian_gaussian_inst.start_for_clone_stream_array_ap_ufixed_16u_array_ap_ufixed_8_0_4_0_0_16u_16_U0_U.if_full_n & gaussian_gaussian_inst.relu_array_ap_fixed_16u_array_ap_ufixed_8_0_4_0_0_16u_relu_config17_U0.ap_start & ~gaussian_gaussian_inst.relu_array_ap_fixed_16u_array_ap_ufixed_8_0_4_0_0_16u_relu_config17_U0.real_start & (trans_in_cnt_14 == trans_out_cnt_14) & ~gaussian_gaussian_inst.start_for_clone_stream_array_ap_ufixed_16u_array_ap_ufixed_8_0_4_0_0_16u_16_U0_U.if_read} start_FIFO}
                        if ((~start_for_clone_stream_array_ap_ufixed_16u_array_ap_ufixed_8_0_4_0_0_16u_16_U0_U.if_full_n & relu_array_ap_fixed_16u_array_ap_ufixed_8_0_4_0_0_16u_relu_config17_U0.ap_start & ~relu_array_ap_fixed_16u_array_ap_ufixed_8_0_4_0_0_16u_relu_config17_U0.real_start & (trans_in_cnt_14 == trans_out_cnt_14) & ~start_for_clone_stream_array_ap_ufixed_16u_array_ap_ufixed_8_0_4_0_0_16u_16_U0_U.if_read)) begin
                            $display("//      Blocked by full output start propagation FIFO 'gaussian_gaussian.start_for_clone_stream_array_ap_ufixed_16u_array_ap_ufixed_8_0_4_0_0_16u_16_U0_U' read by process 'gaussian_gaussian.clone_stream_array_ap_ufixed_16u_array_ap_ufixed_8_0_4_0_0_16u_16_U0',");
                        end
                    end
                    endcase
                end
                15 : begin // for proc 'gaussian_gaussian.clone_stream_array_ap_ufixed_16u_array_ap_ufixed_8_0_4_0_0_16u_16_U0'
                    case(index2)
                    14: begin //  for dep proc 'gaussian_gaussian.relu_array_ap_fixed_16u_array_ap_ufixed_8_0_4_0_0_16u_relu_config17_U0'
// for dep channel 'gaussian_gaussian.layer17_out_U' info is :
// blk sig is {~gaussian_gaussian_inst.clone_stream_array_ap_ufixed_16u_array_ap_ufixed_8_0_4_0_0_16u_16_U0.layer17_out_blk_n data_FIFO}
                        if ((~clone_stream_array_ap_ufixed_16u_array_ap_ufixed_8_0_4_0_0_16u_16_U0.layer17_out_blk_n)) begin
                            if (~layer17_out_U.if_empty_n) begin
                                $display("//      Blocked by empty input FIFO 'gaussian_gaussian.layer17_out_U' written by process 'gaussian_gaussian.relu_array_ap_fixed_16u_array_ap_ufixed_8_0_4_0_0_16u_relu_config17_U0'");
                                $fdisplay(fp, "Dependence_Channel_path gaussian_gaussian.layer17_out_U");
                                $fdisplay(fp, "Dependence_Channel_status EMPTY");
                            end
                            else if (~layer17_out_U.if_full_n) begin
                                $display("//      Blocked by full output FIFO 'gaussian_gaussian.layer17_out_U' read by process 'gaussian_gaussian.relu_array_ap_fixed_16u_array_ap_ufixed_8_0_4_0_0_16u_relu_config17_U0'");
                                $fdisplay(fp, "Dependence_Channel_path gaussian_gaussian.layer17_out_U");
                                $fdisplay(fp, "Dependence_Channel_status FULL");
                            end
                        end
// for dep channel 'gaussian_gaussian.start_for_clone_stream_array_ap_ufixed_16u_array_ap_ufixed_8_0_4_0_0_16u_16_U0_U' info is :
// blk sig is {{~gaussian_gaussian_inst.start_for_clone_stream_array_ap_ufixed_16u_array_ap_ufixed_8_0_4_0_0_16u_16_U0_U.if_empty_n & gaussian_gaussian_inst.clone_stream_array_ap_ufixed_16u_array_ap_ufixed_8_0_4_0_0_16u_16_U0.ap_idle & ~gaussian_gaussian_inst.start_for_clone_stream_array_ap_ufixed_16u_array_ap_ufixed_8_0_4_0_0_16u_16_U0_U.if_write} start_FIFO}
                        if ((~start_for_clone_stream_array_ap_ufixed_16u_array_ap_ufixed_8_0_4_0_0_16u_16_U0_U.if_empty_n & clone_stream_array_ap_ufixed_16u_array_ap_ufixed_8_0_4_0_0_16u_16_U0.ap_idle & ~start_for_clone_stream_array_ap_ufixed_16u_array_ap_ufixed_8_0_4_0_0_16u_16_U0_U.if_write)) begin
                            $display("//      Blocked by missing 'ap_start' from start propagation FIFO 'gaussian_gaussian.start_for_clone_stream_array_ap_ufixed_16u_array_ap_ufixed_8_0_4_0_0_16u_16_U0_U' written by process 'gaussian_gaussian.relu_array_ap_fixed_16u_array_ap_ufixed_8_0_4_0_0_16u_relu_config17_U0',");
                        end
                    end
                    16: begin //  for dep proc 'gaussian_gaussian.dense_array_ap_ufixed_16u_array_ap_fixed_29_11_5_3_0_2u_config18_U0'
// for dep channel 'gaussian_gaussian.layer33_cpy1_U' info is :
// blk sig is {~gaussian_gaussian_inst.clone_stream_array_ap_ufixed_16u_array_ap_ufixed_8_0_4_0_0_16u_16_U0.layer33_cpy1_blk_n data_FIFO}
                        if ((~clone_stream_array_ap_ufixed_16u_array_ap_ufixed_8_0_4_0_0_16u_16_U0.layer33_cpy1_blk_n)) begin
                            if (~layer33_cpy1_U.if_empty_n) begin
                                $display("//      Blocked by empty input FIFO 'gaussian_gaussian.layer33_cpy1_U' written by process 'gaussian_gaussian.dense_array_ap_ufixed_16u_array_ap_fixed_29_11_5_3_0_2u_config18_U0'");
                                $fdisplay(fp, "Dependence_Channel_path gaussian_gaussian.layer33_cpy1_U");
                                $fdisplay(fp, "Dependence_Channel_status EMPTY");
                            end
                            else if (~layer33_cpy1_U.if_full_n) begin
                                $display("//      Blocked by full output FIFO 'gaussian_gaussian.layer33_cpy1_U' read by process 'gaussian_gaussian.dense_array_ap_ufixed_16u_array_ap_fixed_29_11_5_3_0_2u_config18_U0'");
                                $fdisplay(fp, "Dependence_Channel_path gaussian_gaussian.layer33_cpy1_U");
                                $fdisplay(fp, "Dependence_Channel_status FULL");
                            end
                        end
// for dep channel 'gaussian_gaussian.start_for_dense_array_ap_ufixed_16u_array_ap_fixed_29_11_5_3_0_2u_config18_U0_U' info is :
// blk sig is {{~gaussian_gaussian_inst.start_for_dense_array_ap_ufixed_16u_array_ap_fixed_29_11_5_3_0_2u_config18_U0_U.if_full_n & gaussian_gaussian_inst.clone_stream_array_ap_ufixed_16u_array_ap_ufixed_8_0_4_0_0_16u_16_U0.ap_start & ~gaussian_gaussian_inst.clone_stream_array_ap_ufixed_16u_array_ap_ufixed_8_0_4_0_0_16u_16_U0.real_start & (trans_in_cnt_15 == trans_out_cnt_15) & ~gaussian_gaussian_inst.start_for_dense_array_ap_ufixed_16u_array_ap_fixed_29_11_5_3_0_2u_config18_U0_U.if_read} start_FIFO}
                        if ((~start_for_dense_array_ap_ufixed_16u_array_ap_fixed_29_11_5_3_0_2u_config18_U0_U.if_full_n & clone_stream_array_ap_ufixed_16u_array_ap_ufixed_8_0_4_0_0_16u_16_U0.ap_start & ~clone_stream_array_ap_ufixed_16u_array_ap_ufixed_8_0_4_0_0_16u_16_U0.real_start & (trans_in_cnt_15 == trans_out_cnt_15) & ~start_for_dense_array_ap_ufixed_16u_array_ap_fixed_29_11_5_3_0_2u_config18_U0_U.if_read)) begin
                            $display("//      Blocked by full output start propagation FIFO 'gaussian_gaussian.start_for_dense_array_ap_ufixed_16u_array_ap_fixed_29_11_5_3_0_2u_config18_U0_U' read by process 'gaussian_gaussian.dense_array_ap_ufixed_16u_array_ap_fixed_29_11_5_3_0_2u_config18_U0',");
                        end
                    end
                    17: begin //  for dep proc 'gaussian_gaussian.dense_array_ap_ufixed_16u_array_ap_fixed_29_11_5_3_0_2u_config20_U0'
// for dep channel 'gaussian_gaussian.layer33_cpy2_U' info is :
// blk sig is {~gaussian_gaussian_inst.clone_stream_array_ap_ufixed_16u_array_ap_ufixed_8_0_4_0_0_16u_16_U0.layer33_cpy2_blk_n data_FIFO}
                        if ((~clone_stream_array_ap_ufixed_16u_array_ap_ufixed_8_0_4_0_0_16u_16_U0.layer33_cpy2_blk_n)) begin
                            if (~layer33_cpy2_U.if_empty_n) begin
                                $display("//      Blocked by empty input FIFO 'gaussian_gaussian.layer33_cpy2_U' written by process 'gaussian_gaussian.dense_array_ap_ufixed_16u_array_ap_fixed_29_11_5_3_0_2u_config20_U0'");
                                $fdisplay(fp, "Dependence_Channel_path gaussian_gaussian.layer33_cpy2_U");
                                $fdisplay(fp, "Dependence_Channel_status EMPTY");
                            end
                            else if (~layer33_cpy2_U.if_full_n) begin
                                $display("//      Blocked by full output FIFO 'gaussian_gaussian.layer33_cpy2_U' read by process 'gaussian_gaussian.dense_array_ap_ufixed_16u_array_ap_fixed_29_11_5_3_0_2u_config20_U0'");
                                $fdisplay(fp, "Dependence_Channel_path gaussian_gaussian.layer33_cpy2_U");
                                $fdisplay(fp, "Dependence_Channel_status FULL");
                            end
                        end
// for dep channel 'gaussian_gaussian.start_for_dense_array_ap_ufixed_16u_array_ap_fixed_29_11_5_3_0_2u_config20_U0_U' info is :
// blk sig is {{~gaussian_gaussian_inst.start_for_dense_array_ap_ufixed_16u_array_ap_fixed_29_11_5_3_0_2u_config20_U0_U.if_full_n & gaussian_gaussian_inst.clone_stream_array_ap_ufixed_16u_array_ap_ufixed_8_0_4_0_0_16u_16_U0.ap_start & ~gaussian_gaussian_inst.clone_stream_array_ap_ufixed_16u_array_ap_ufixed_8_0_4_0_0_16u_16_U0.real_start & (trans_in_cnt_15 == trans_out_cnt_15) & ~gaussian_gaussian_inst.start_for_dense_array_ap_ufixed_16u_array_ap_fixed_29_11_5_3_0_2u_config20_U0_U.if_read} start_FIFO}
                        if ((~start_for_dense_array_ap_ufixed_16u_array_ap_fixed_29_11_5_3_0_2u_config20_U0_U.if_full_n & clone_stream_array_ap_ufixed_16u_array_ap_ufixed_8_0_4_0_0_16u_16_U0.ap_start & ~clone_stream_array_ap_ufixed_16u_array_ap_ufixed_8_0_4_0_0_16u_16_U0.real_start & (trans_in_cnt_15 == trans_out_cnt_15) & ~start_for_dense_array_ap_ufixed_16u_array_ap_fixed_29_11_5_3_0_2u_config20_U0_U.if_read)) begin
                            $display("//      Blocked by full output start propagation FIFO 'gaussian_gaussian.start_for_dense_array_ap_ufixed_16u_array_ap_fixed_29_11_5_3_0_2u_config20_U0_U' read by process 'gaussian_gaussian.dense_array_ap_ufixed_16u_array_ap_fixed_29_11_5_3_0_2u_config20_U0',");
                        end
                    end
                    18: begin //  for dep proc 'gaussian_gaussian.dense_array_ap_ufixed_16u_array_ap_fixed_29_11_5_3_0_2u_config22_U0'
// for dep channel 'gaussian_gaussian.layer33_cpy3_U' info is :
// blk sig is {~gaussian_gaussian_inst.clone_stream_array_ap_ufixed_16u_array_ap_ufixed_8_0_4_0_0_16u_16_U0.layer33_cpy3_blk_n data_FIFO}
                        if ((~clone_stream_array_ap_ufixed_16u_array_ap_ufixed_8_0_4_0_0_16u_16_U0.layer33_cpy3_blk_n)) begin
                            if (~layer33_cpy3_U.if_empty_n) begin
                                $display("//      Blocked by empty input FIFO 'gaussian_gaussian.layer33_cpy3_U' written by process 'gaussian_gaussian.dense_array_ap_ufixed_16u_array_ap_fixed_29_11_5_3_0_2u_config22_U0'");
                                $fdisplay(fp, "Dependence_Channel_path gaussian_gaussian.layer33_cpy3_U");
                                $fdisplay(fp, "Dependence_Channel_status EMPTY");
                            end
                            else if (~layer33_cpy3_U.if_full_n) begin
                                $display("//      Blocked by full output FIFO 'gaussian_gaussian.layer33_cpy3_U' read by process 'gaussian_gaussian.dense_array_ap_ufixed_16u_array_ap_fixed_29_11_5_3_0_2u_config22_U0'");
                                $fdisplay(fp, "Dependence_Channel_path gaussian_gaussian.layer33_cpy3_U");
                                $fdisplay(fp, "Dependence_Channel_status FULL");
                            end
                        end
// for dep channel 'gaussian_gaussian.start_for_dense_array_ap_ufixed_16u_array_ap_fixed_29_11_5_3_0_2u_config22_U0_U' info is :
// blk sig is {{~gaussian_gaussian_inst.start_for_dense_array_ap_ufixed_16u_array_ap_fixed_29_11_5_3_0_2u_config22_U0_U.if_full_n & gaussian_gaussian_inst.clone_stream_array_ap_ufixed_16u_array_ap_ufixed_8_0_4_0_0_16u_16_U0.ap_start & ~gaussian_gaussian_inst.clone_stream_array_ap_ufixed_16u_array_ap_ufixed_8_0_4_0_0_16u_16_U0.real_start & (trans_in_cnt_15 == trans_out_cnt_15) & ~gaussian_gaussian_inst.start_for_dense_array_ap_ufixed_16u_array_ap_fixed_29_11_5_3_0_2u_config22_U0_U.if_read} start_FIFO}
                        if ((~start_for_dense_array_ap_ufixed_16u_array_ap_fixed_29_11_5_3_0_2u_config22_U0_U.if_full_n & clone_stream_array_ap_ufixed_16u_array_ap_ufixed_8_0_4_0_0_16u_16_U0.ap_start & ~clone_stream_array_ap_ufixed_16u_array_ap_ufixed_8_0_4_0_0_16u_16_U0.real_start & (trans_in_cnt_15 == trans_out_cnt_15) & ~start_for_dense_array_ap_ufixed_16u_array_ap_fixed_29_11_5_3_0_2u_config22_U0_U.if_read)) begin
                            $display("//      Blocked by full output start propagation FIFO 'gaussian_gaussian.start_for_dense_array_ap_ufixed_16u_array_ap_fixed_29_11_5_3_0_2u_config22_U0_U' read by process 'gaussian_gaussian.dense_array_ap_ufixed_16u_array_ap_fixed_29_11_5_3_0_2u_config22_U0',");
                        end
                    end
                    19: begin //  for dep proc 'gaussian_gaussian.dense_array_ap_ufixed_16u_array_ap_fixed_29_11_5_3_0_1u_config24_U0'
// for dep channel 'gaussian_gaussian.layer33_cpy4_U' info is :
// blk sig is {~gaussian_gaussian_inst.clone_stream_array_ap_ufixed_16u_array_ap_ufixed_8_0_4_0_0_16u_16_U0.layer33_cpy4_blk_n data_FIFO}
                        if ((~clone_stream_array_ap_ufixed_16u_array_ap_ufixed_8_0_4_0_0_16u_16_U0.layer33_cpy4_blk_n)) begin
                            if (~layer33_cpy4_U.if_empty_n) begin
                                $display("//      Blocked by empty input FIFO 'gaussian_gaussian.layer33_cpy4_U' written by process 'gaussian_gaussian.dense_array_ap_ufixed_16u_array_ap_fixed_29_11_5_3_0_1u_config24_U0'");
                                $fdisplay(fp, "Dependence_Channel_path gaussian_gaussian.layer33_cpy4_U");
                                $fdisplay(fp, "Dependence_Channel_status EMPTY");
                            end
                            else if (~layer33_cpy4_U.if_full_n) begin
                                $display("//      Blocked by full output FIFO 'gaussian_gaussian.layer33_cpy4_U' read by process 'gaussian_gaussian.dense_array_ap_ufixed_16u_array_ap_fixed_29_11_5_3_0_1u_config24_U0'");
                                $fdisplay(fp, "Dependence_Channel_path gaussian_gaussian.layer33_cpy4_U");
                                $fdisplay(fp, "Dependence_Channel_status FULL");
                            end
                        end
// for dep channel 'gaussian_gaussian.start_for_dense_array_ap_ufixed_16u_array_ap_fixed_29_11_5_3_0_1u_config24_U0_U' info is :
// blk sig is {{~gaussian_gaussian_inst.start_for_dense_array_ap_ufixed_16u_array_ap_fixed_29_11_5_3_0_1u_config24_U0_U.if_full_n & gaussian_gaussian_inst.clone_stream_array_ap_ufixed_16u_array_ap_ufixed_8_0_4_0_0_16u_16_U0.ap_start & ~gaussian_gaussian_inst.clone_stream_array_ap_ufixed_16u_array_ap_ufixed_8_0_4_0_0_16u_16_U0.real_start & (trans_in_cnt_15 == trans_out_cnt_15) & ~gaussian_gaussian_inst.start_for_dense_array_ap_ufixed_16u_array_ap_fixed_29_11_5_3_0_1u_config24_U0_U.if_read} start_FIFO}
                        if ((~start_for_dense_array_ap_ufixed_16u_array_ap_fixed_29_11_5_3_0_1u_config24_U0_U.if_full_n & clone_stream_array_ap_ufixed_16u_array_ap_ufixed_8_0_4_0_0_16u_16_U0.ap_start & ~clone_stream_array_ap_ufixed_16u_array_ap_ufixed_8_0_4_0_0_16u_16_U0.real_start & (trans_in_cnt_15 == trans_out_cnt_15) & ~start_for_dense_array_ap_ufixed_16u_array_ap_fixed_29_11_5_3_0_1u_config24_U0_U.if_read)) begin
                            $display("//      Blocked by full output start propagation FIFO 'gaussian_gaussian.start_for_dense_array_ap_ufixed_16u_array_ap_fixed_29_11_5_3_0_1u_config24_U0_U' read by process 'gaussian_gaussian.dense_array_ap_ufixed_16u_array_ap_fixed_29_11_5_3_0_1u_config24_U0',");
                        end
                    end
                    endcase
                end
                16 : begin // for proc 'gaussian_gaussian.dense_array_ap_ufixed_16u_array_ap_fixed_29_11_5_3_0_2u_config18_U0'
                    case(index2)
                    15: begin //  for dep proc 'gaussian_gaussian.clone_stream_array_ap_ufixed_16u_array_ap_ufixed_8_0_4_0_0_16u_16_U0'
// for dep channel 'gaussian_gaussian.layer33_cpy1_U' info is :
// blk sig is {~gaussian_gaussian_inst.dense_array_ap_ufixed_16u_array_ap_fixed_29_11_5_3_0_2u_config18_U0.layer33_cpy1_blk_n data_FIFO}
                        if ((~dense_array_ap_ufixed_16u_array_ap_fixed_29_11_5_3_0_2u_config18_U0.layer33_cpy1_blk_n)) begin
                            if (~layer33_cpy1_U.if_empty_n) begin
                                $display("//      Blocked by empty input FIFO 'gaussian_gaussian.layer33_cpy1_U' written by process 'gaussian_gaussian.clone_stream_array_ap_ufixed_16u_array_ap_ufixed_8_0_4_0_0_16u_16_U0'");
                                $fdisplay(fp, "Dependence_Channel_path gaussian_gaussian.layer33_cpy1_U");
                                $fdisplay(fp, "Dependence_Channel_status EMPTY");
                            end
                            else if (~layer33_cpy1_U.if_full_n) begin
                                $display("//      Blocked by full output FIFO 'gaussian_gaussian.layer33_cpy1_U' read by process 'gaussian_gaussian.clone_stream_array_ap_ufixed_16u_array_ap_ufixed_8_0_4_0_0_16u_16_U0'");
                                $fdisplay(fp, "Dependence_Channel_path gaussian_gaussian.layer33_cpy1_U");
                                $fdisplay(fp, "Dependence_Channel_status FULL");
                            end
                        end
// for dep channel 'gaussian_gaussian.start_for_dense_array_ap_ufixed_16u_array_ap_fixed_29_11_5_3_0_2u_config18_U0_U' info is :
// blk sig is {{~gaussian_gaussian_inst.start_for_dense_array_ap_ufixed_16u_array_ap_fixed_29_11_5_3_0_2u_config18_U0_U.if_empty_n & gaussian_gaussian_inst.dense_array_ap_ufixed_16u_array_ap_fixed_29_11_5_3_0_2u_config18_U0.ap_idle & ~gaussian_gaussian_inst.start_for_dense_array_ap_ufixed_16u_array_ap_fixed_29_11_5_3_0_2u_config18_U0_U.if_write} start_FIFO}
                        if ((~start_for_dense_array_ap_ufixed_16u_array_ap_fixed_29_11_5_3_0_2u_config18_U0_U.if_empty_n & dense_array_ap_ufixed_16u_array_ap_fixed_29_11_5_3_0_2u_config18_U0.ap_idle & ~start_for_dense_array_ap_ufixed_16u_array_ap_fixed_29_11_5_3_0_2u_config18_U0_U.if_write)) begin
                            $display("//      Blocked by missing 'ap_start' from start propagation FIFO 'gaussian_gaussian.start_for_dense_array_ap_ufixed_16u_array_ap_fixed_29_11_5_3_0_2u_config18_U0_U' written by process 'gaussian_gaussian.clone_stream_array_ap_ufixed_16u_array_ap_ufixed_8_0_4_0_0_16u_16_U0',");
                        end
                    end
                    20: begin //  for dep proc 'gaussian_gaussian.sigmoid_array_array_ap_fixed_16_6_5_3_0_2u_sigmoid_config26_U0'
// for dep channel 'gaussian_gaussian.layer18_out_U' info is :
// blk sig is {~gaussian_gaussian_inst.dense_array_ap_ufixed_16u_array_ap_fixed_29_11_5_3_0_2u_config18_U0.layer18_out_blk_n data_FIFO}
                        if ((~dense_array_ap_ufixed_16u_array_ap_fixed_29_11_5_3_0_2u_config18_U0.layer18_out_blk_n)) begin
                            if (~layer18_out_U.if_empty_n) begin
                                $display("//      Blocked by empty input FIFO 'gaussian_gaussian.layer18_out_U' written by process 'gaussian_gaussian.sigmoid_array_array_ap_fixed_16_6_5_3_0_2u_sigmoid_config26_U0'");
                                $fdisplay(fp, "Dependence_Channel_path gaussian_gaussian.layer18_out_U");
                                $fdisplay(fp, "Dependence_Channel_status EMPTY");
                            end
                            else if (~layer18_out_U.if_full_n) begin
                                $display("//      Blocked by full output FIFO 'gaussian_gaussian.layer18_out_U' read by process 'gaussian_gaussian.sigmoid_array_array_ap_fixed_16_6_5_3_0_2u_sigmoid_config26_U0'");
                                $fdisplay(fp, "Dependence_Channel_path gaussian_gaussian.layer18_out_U");
                                $fdisplay(fp, "Dependence_Channel_status FULL");
                            end
                        end
// for dep channel 'gaussian_gaussian.start_for_sigmoid_array_array_ap_fixed_16_6_5_3_0_2u_sigmoid_config26_U0_U' info is :
// blk sig is {{~gaussian_gaussian_inst.start_for_sigmoid_array_array_ap_fixed_16_6_5_3_0_2u_sigmoid_config26_U0_U.if_full_n & gaussian_gaussian_inst.dense_array_ap_ufixed_16u_array_ap_fixed_29_11_5_3_0_2u_config18_U0.ap_start & ~gaussian_gaussian_inst.dense_array_ap_ufixed_16u_array_ap_fixed_29_11_5_3_0_2u_config18_U0.real_start & (trans_in_cnt_16 == trans_out_cnt_16) & ~gaussian_gaussian_inst.start_for_sigmoid_array_array_ap_fixed_16_6_5_3_0_2u_sigmoid_config26_U0_U.if_read} start_FIFO}
                        if ((~start_for_sigmoid_array_array_ap_fixed_16_6_5_3_0_2u_sigmoid_config26_U0_U.if_full_n & dense_array_ap_ufixed_16u_array_ap_fixed_29_11_5_3_0_2u_config18_U0.ap_start & ~dense_array_ap_ufixed_16u_array_ap_fixed_29_11_5_3_0_2u_config18_U0.real_start & (trans_in_cnt_16 == trans_out_cnt_16) & ~start_for_sigmoid_array_array_ap_fixed_16_6_5_3_0_2u_sigmoid_config26_U0_U.if_read)) begin
                            $display("//      Blocked by full output start propagation FIFO 'gaussian_gaussian.start_for_sigmoid_array_array_ap_fixed_16_6_5_3_0_2u_sigmoid_config26_U0_U' read by process 'gaussian_gaussian.sigmoid_array_array_ap_fixed_16_6_5_3_0_2u_sigmoid_config26_U0',");
                        end
                    end
                    endcase
                end
                17 : begin // for proc 'gaussian_gaussian.dense_array_ap_ufixed_16u_array_ap_fixed_29_11_5_3_0_2u_config20_U0'
                    case(index2)
                    15: begin //  for dep proc 'gaussian_gaussian.clone_stream_array_ap_ufixed_16u_array_ap_ufixed_8_0_4_0_0_16u_16_U0'
// for dep channel 'gaussian_gaussian.layer33_cpy2_U' info is :
// blk sig is {~gaussian_gaussian_inst.dense_array_ap_ufixed_16u_array_ap_fixed_29_11_5_3_0_2u_config20_U0.layer33_cpy2_blk_n data_FIFO}
                        if ((~dense_array_ap_ufixed_16u_array_ap_fixed_29_11_5_3_0_2u_config20_U0.layer33_cpy2_blk_n)) begin
                            if (~layer33_cpy2_U.if_empty_n) begin
                                $display("//      Blocked by empty input FIFO 'gaussian_gaussian.layer33_cpy2_U' written by process 'gaussian_gaussian.clone_stream_array_ap_ufixed_16u_array_ap_ufixed_8_0_4_0_0_16u_16_U0'");
                                $fdisplay(fp, "Dependence_Channel_path gaussian_gaussian.layer33_cpy2_U");
                                $fdisplay(fp, "Dependence_Channel_status EMPTY");
                            end
                            else if (~layer33_cpy2_U.if_full_n) begin
                                $display("//      Blocked by full output FIFO 'gaussian_gaussian.layer33_cpy2_U' read by process 'gaussian_gaussian.clone_stream_array_ap_ufixed_16u_array_ap_ufixed_8_0_4_0_0_16u_16_U0'");
                                $fdisplay(fp, "Dependence_Channel_path gaussian_gaussian.layer33_cpy2_U");
                                $fdisplay(fp, "Dependence_Channel_status FULL");
                            end
                        end
// for dep channel 'gaussian_gaussian.start_for_dense_array_ap_ufixed_16u_array_ap_fixed_29_11_5_3_0_2u_config20_U0_U' info is :
// blk sig is {{~gaussian_gaussian_inst.start_for_dense_array_ap_ufixed_16u_array_ap_fixed_29_11_5_3_0_2u_config20_U0_U.if_empty_n & gaussian_gaussian_inst.dense_array_ap_ufixed_16u_array_ap_fixed_29_11_5_3_0_2u_config20_U0.ap_idle & ~gaussian_gaussian_inst.start_for_dense_array_ap_ufixed_16u_array_ap_fixed_29_11_5_3_0_2u_config20_U0_U.if_write} start_FIFO}
                        if ((~start_for_dense_array_ap_ufixed_16u_array_ap_fixed_29_11_5_3_0_2u_config20_U0_U.if_empty_n & dense_array_ap_ufixed_16u_array_ap_fixed_29_11_5_3_0_2u_config20_U0.ap_idle & ~start_for_dense_array_ap_ufixed_16u_array_ap_fixed_29_11_5_3_0_2u_config20_U0_U.if_write)) begin
                            $display("//      Blocked by missing 'ap_start' from start propagation FIFO 'gaussian_gaussian.start_for_dense_array_ap_ufixed_16u_array_ap_fixed_29_11_5_3_0_2u_config20_U0_U' written by process 'gaussian_gaussian.clone_stream_array_ap_ufixed_16u_array_ap_ufixed_8_0_4_0_0_16u_16_U0',");
                        end
                    end
                    21: begin //  for dep proc 'gaussian_gaussian.softplus_array_array_ap_fixed_16_6_5_3_0_2u_softplus_config27_U0'
// for dep channel 'gaussian_gaussian.layer20_out_U' info is :
// blk sig is {~gaussian_gaussian_inst.dense_array_ap_ufixed_16u_array_ap_fixed_29_11_5_3_0_2u_config20_U0.layer20_out_blk_n data_FIFO}
                        if ((~dense_array_ap_ufixed_16u_array_ap_fixed_29_11_5_3_0_2u_config20_U0.layer20_out_blk_n)) begin
                            if (~layer20_out_U.if_empty_n) begin
                                $display("//      Blocked by empty input FIFO 'gaussian_gaussian.layer20_out_U' written by process 'gaussian_gaussian.softplus_array_array_ap_fixed_16_6_5_3_0_2u_softplus_config27_U0'");
                                $fdisplay(fp, "Dependence_Channel_path gaussian_gaussian.layer20_out_U");
                                $fdisplay(fp, "Dependence_Channel_status EMPTY");
                            end
                            else if (~layer20_out_U.if_full_n) begin
                                $display("//      Blocked by full output FIFO 'gaussian_gaussian.layer20_out_U' read by process 'gaussian_gaussian.softplus_array_array_ap_fixed_16_6_5_3_0_2u_softplus_config27_U0'");
                                $fdisplay(fp, "Dependence_Channel_path gaussian_gaussian.layer20_out_U");
                                $fdisplay(fp, "Dependence_Channel_status FULL");
                            end
                        end
// for dep channel 'gaussian_gaussian.start_for_softplus_array_array_ap_fixed_16_6_5_3_0_2u_softplus_config27_U0_U' info is :
// blk sig is {{~gaussian_gaussian_inst.start_for_softplus_array_array_ap_fixed_16_6_5_3_0_2u_softplus_config27_U0_U.if_full_n & gaussian_gaussian_inst.dense_array_ap_ufixed_16u_array_ap_fixed_29_11_5_3_0_2u_config20_U0.ap_start & ~gaussian_gaussian_inst.dense_array_ap_ufixed_16u_array_ap_fixed_29_11_5_3_0_2u_config20_U0.real_start & (trans_in_cnt_17 == trans_out_cnt_17) & ~gaussian_gaussian_inst.start_for_softplus_array_array_ap_fixed_16_6_5_3_0_2u_softplus_config27_U0_U.if_read} start_FIFO}
                        if ((~start_for_softplus_array_array_ap_fixed_16_6_5_3_0_2u_softplus_config27_U0_U.if_full_n & dense_array_ap_ufixed_16u_array_ap_fixed_29_11_5_3_0_2u_config20_U0.ap_start & ~dense_array_ap_ufixed_16u_array_ap_fixed_29_11_5_3_0_2u_config20_U0.real_start & (trans_in_cnt_17 == trans_out_cnt_17) & ~start_for_softplus_array_array_ap_fixed_16_6_5_3_0_2u_softplus_config27_U0_U.if_read)) begin
                            $display("//      Blocked by full output start propagation FIFO 'gaussian_gaussian.start_for_softplus_array_array_ap_fixed_16_6_5_3_0_2u_softplus_config27_U0_U' read by process 'gaussian_gaussian.softplus_array_array_ap_fixed_16_6_5_3_0_2u_softplus_config27_U0',");
                        end
                    end
                    endcase
                end
                18 : begin // for proc 'gaussian_gaussian.dense_array_ap_ufixed_16u_array_ap_fixed_29_11_5_3_0_2u_config22_U0'
                    case(index2)
                    15: begin //  for dep proc 'gaussian_gaussian.clone_stream_array_ap_ufixed_16u_array_ap_ufixed_8_0_4_0_0_16u_16_U0'
// for dep channel 'gaussian_gaussian.layer33_cpy3_U' info is :
// blk sig is {~gaussian_gaussian_inst.dense_array_ap_ufixed_16u_array_ap_fixed_29_11_5_3_0_2u_config22_U0.layer33_cpy3_blk_n data_FIFO}
                        if ((~dense_array_ap_ufixed_16u_array_ap_fixed_29_11_5_3_0_2u_config22_U0.layer33_cpy3_blk_n)) begin
                            if (~layer33_cpy3_U.if_empty_n) begin
                                $display("//      Blocked by empty input FIFO 'gaussian_gaussian.layer33_cpy3_U' written by process 'gaussian_gaussian.clone_stream_array_ap_ufixed_16u_array_ap_ufixed_8_0_4_0_0_16u_16_U0'");
                                $fdisplay(fp, "Dependence_Channel_path gaussian_gaussian.layer33_cpy3_U");
                                $fdisplay(fp, "Dependence_Channel_status EMPTY");
                            end
                            else if (~layer33_cpy3_U.if_full_n) begin
                                $display("//      Blocked by full output FIFO 'gaussian_gaussian.layer33_cpy3_U' read by process 'gaussian_gaussian.clone_stream_array_ap_ufixed_16u_array_ap_ufixed_8_0_4_0_0_16u_16_U0'");
                                $fdisplay(fp, "Dependence_Channel_path gaussian_gaussian.layer33_cpy3_U");
                                $fdisplay(fp, "Dependence_Channel_status FULL");
                            end
                        end
// for dep channel 'gaussian_gaussian.start_for_dense_array_ap_ufixed_16u_array_ap_fixed_29_11_5_3_0_2u_config22_U0_U' info is :
// blk sig is {{~gaussian_gaussian_inst.start_for_dense_array_ap_ufixed_16u_array_ap_fixed_29_11_5_3_0_2u_config22_U0_U.if_empty_n & gaussian_gaussian_inst.dense_array_ap_ufixed_16u_array_ap_fixed_29_11_5_3_0_2u_config22_U0.ap_idle & ~gaussian_gaussian_inst.start_for_dense_array_ap_ufixed_16u_array_ap_fixed_29_11_5_3_0_2u_config22_U0_U.if_write} start_FIFO}
                        if ((~start_for_dense_array_ap_ufixed_16u_array_ap_fixed_29_11_5_3_0_2u_config22_U0_U.if_empty_n & dense_array_ap_ufixed_16u_array_ap_fixed_29_11_5_3_0_2u_config22_U0.ap_idle & ~start_for_dense_array_ap_ufixed_16u_array_ap_fixed_29_11_5_3_0_2u_config22_U0_U.if_write)) begin
                            $display("//      Blocked by missing 'ap_start' from start propagation FIFO 'gaussian_gaussian.start_for_dense_array_ap_ufixed_16u_array_ap_fixed_29_11_5_3_0_2u_config22_U0_U' written by process 'gaussian_gaussian.clone_stream_array_ap_ufixed_16u_array_ap_ufixed_8_0_4_0_0_16u_16_U0',");
                        end
                    end
                    22: begin //  for dep proc 'gaussian_gaussian.tanh_array_ap_fixed_2u_array_ap_fixed_16_6_5_3_0_2u_tanh_config28_U0'
// for dep channel 'gaussian_gaussian.layer22_out_U' info is :
// blk sig is {~gaussian_gaussian_inst.dense_array_ap_ufixed_16u_array_ap_fixed_29_11_5_3_0_2u_config22_U0.layer22_out_blk_n data_FIFO}
                        if ((~dense_array_ap_ufixed_16u_array_ap_fixed_29_11_5_3_0_2u_config22_U0.layer22_out_blk_n)) begin
                            if (~layer22_out_U.if_empty_n) begin
                                $display("//      Blocked by empty input FIFO 'gaussian_gaussian.layer22_out_U' written by process 'gaussian_gaussian.tanh_array_ap_fixed_2u_array_ap_fixed_16_6_5_3_0_2u_tanh_config28_U0'");
                                $fdisplay(fp, "Dependence_Channel_path gaussian_gaussian.layer22_out_U");
                                $fdisplay(fp, "Dependence_Channel_status EMPTY");
                            end
                            else if (~layer22_out_U.if_full_n) begin
                                $display("//      Blocked by full output FIFO 'gaussian_gaussian.layer22_out_U' read by process 'gaussian_gaussian.tanh_array_ap_fixed_2u_array_ap_fixed_16_6_5_3_0_2u_tanh_config28_U0'");
                                $fdisplay(fp, "Dependence_Channel_path gaussian_gaussian.layer22_out_U");
                                $fdisplay(fp, "Dependence_Channel_status FULL");
                            end
                        end
// for dep channel 'gaussian_gaussian.start_for_tanh_array_ap_fixed_2u_array_ap_fixed_16_6_5_3_0_2u_tanh_config28_U0_U' info is :
// blk sig is {{~gaussian_gaussian_inst.start_for_tanh_array_ap_fixed_2u_array_ap_fixed_16_6_5_3_0_2u_tanh_config28_U0_U.if_full_n & gaussian_gaussian_inst.dense_array_ap_ufixed_16u_array_ap_fixed_29_11_5_3_0_2u_config22_U0.ap_start & ~gaussian_gaussian_inst.dense_array_ap_ufixed_16u_array_ap_fixed_29_11_5_3_0_2u_config22_U0.real_start & (trans_in_cnt_18 == trans_out_cnt_18) & ~gaussian_gaussian_inst.start_for_tanh_array_ap_fixed_2u_array_ap_fixed_16_6_5_3_0_2u_tanh_config28_U0_U.if_read} start_FIFO}
                        if ((~start_for_tanh_array_ap_fixed_2u_array_ap_fixed_16_6_5_3_0_2u_tanh_config28_U0_U.if_full_n & dense_array_ap_ufixed_16u_array_ap_fixed_29_11_5_3_0_2u_config22_U0.ap_start & ~dense_array_ap_ufixed_16u_array_ap_fixed_29_11_5_3_0_2u_config22_U0.real_start & (trans_in_cnt_18 == trans_out_cnt_18) & ~start_for_tanh_array_ap_fixed_2u_array_ap_fixed_16_6_5_3_0_2u_tanh_config28_U0_U.if_read)) begin
                            $display("//      Blocked by full output start propagation FIFO 'gaussian_gaussian.start_for_tanh_array_ap_fixed_2u_array_ap_fixed_16_6_5_3_0_2u_tanh_config28_U0_U' read by process 'gaussian_gaussian.tanh_array_ap_fixed_2u_array_ap_fixed_16_6_5_3_0_2u_tanh_config28_U0',");
                        end
                    end
                    endcase
                end
                19 : begin // for proc 'gaussian_gaussian.dense_array_ap_ufixed_16u_array_ap_fixed_29_11_5_3_0_1u_config24_U0'
                    case(index2)
                    15: begin //  for dep proc 'gaussian_gaussian.clone_stream_array_ap_ufixed_16u_array_ap_ufixed_8_0_4_0_0_16u_16_U0'
// for dep channel 'gaussian_gaussian.layer33_cpy4_U' info is :
// blk sig is {~gaussian_gaussian_inst.dense_array_ap_ufixed_16u_array_ap_fixed_29_11_5_3_0_1u_config24_U0.layer33_cpy4_blk_n data_FIFO}
                        if ((~dense_array_ap_ufixed_16u_array_ap_fixed_29_11_5_3_0_1u_config24_U0.layer33_cpy4_blk_n)) begin
                            if (~layer33_cpy4_U.if_empty_n) begin
                                $display("//      Blocked by empty input FIFO 'gaussian_gaussian.layer33_cpy4_U' written by process 'gaussian_gaussian.clone_stream_array_ap_ufixed_16u_array_ap_ufixed_8_0_4_0_0_16u_16_U0'");
                                $fdisplay(fp, "Dependence_Channel_path gaussian_gaussian.layer33_cpy4_U");
                                $fdisplay(fp, "Dependence_Channel_status EMPTY");
                            end
                            else if (~layer33_cpy4_U.if_full_n) begin
                                $display("//      Blocked by full output FIFO 'gaussian_gaussian.layer33_cpy4_U' read by process 'gaussian_gaussian.clone_stream_array_ap_ufixed_16u_array_ap_ufixed_8_0_4_0_0_16u_16_U0'");
                                $fdisplay(fp, "Dependence_Channel_path gaussian_gaussian.layer33_cpy4_U");
                                $fdisplay(fp, "Dependence_Channel_status FULL");
                            end
                        end
// for dep channel 'gaussian_gaussian.start_for_dense_array_ap_ufixed_16u_array_ap_fixed_29_11_5_3_0_1u_config24_U0_U' info is :
// blk sig is {{~gaussian_gaussian_inst.start_for_dense_array_ap_ufixed_16u_array_ap_fixed_29_11_5_3_0_1u_config24_U0_U.if_empty_n & gaussian_gaussian_inst.dense_array_ap_ufixed_16u_array_ap_fixed_29_11_5_3_0_1u_config24_U0.ap_idle & ~gaussian_gaussian_inst.start_for_dense_array_ap_ufixed_16u_array_ap_fixed_29_11_5_3_0_1u_config24_U0_U.if_write} start_FIFO}
                        if ((~start_for_dense_array_ap_ufixed_16u_array_ap_fixed_29_11_5_3_0_1u_config24_U0_U.if_empty_n & dense_array_ap_ufixed_16u_array_ap_fixed_29_11_5_3_0_1u_config24_U0.ap_idle & ~start_for_dense_array_ap_ufixed_16u_array_ap_fixed_29_11_5_3_0_1u_config24_U0_U.if_write)) begin
                            $display("//      Blocked by missing 'ap_start' from start propagation FIFO 'gaussian_gaussian.start_for_dense_array_ap_ufixed_16u_array_ap_fixed_29_11_5_3_0_1u_config24_U0_U' written by process 'gaussian_gaussian.clone_stream_array_ap_ufixed_16u_array_ap_ufixed_8_0_4_0_0_16u_16_U0',");
                        end
                    end
                    23: begin //  for dep proc 'gaussian_gaussian.sigmoid_array_array_ap_fixed_16_6_5_3_0_1u_sigmoid_config29_U0'
// for dep channel 'gaussian_gaussian.layer24_out_U' info is :
// blk sig is {~gaussian_gaussian_inst.dense_array_ap_ufixed_16u_array_ap_fixed_29_11_5_3_0_1u_config24_U0.layer24_out_blk_n data_FIFO}
                        if ((~dense_array_ap_ufixed_16u_array_ap_fixed_29_11_5_3_0_1u_config24_U0.layer24_out_blk_n)) begin
                            if (~layer24_out_U.if_empty_n) begin
                                $display("//      Blocked by empty input FIFO 'gaussian_gaussian.layer24_out_U' written by process 'gaussian_gaussian.sigmoid_array_array_ap_fixed_16_6_5_3_0_1u_sigmoid_config29_U0'");
                                $fdisplay(fp, "Dependence_Channel_path gaussian_gaussian.layer24_out_U");
                                $fdisplay(fp, "Dependence_Channel_status EMPTY");
                            end
                            else if (~layer24_out_U.if_full_n) begin
                                $display("//      Blocked by full output FIFO 'gaussian_gaussian.layer24_out_U' read by process 'gaussian_gaussian.sigmoid_array_array_ap_fixed_16_6_5_3_0_1u_sigmoid_config29_U0'");
                                $fdisplay(fp, "Dependence_Channel_path gaussian_gaussian.layer24_out_U");
                                $fdisplay(fp, "Dependence_Channel_status FULL");
                            end
                        end
// for dep channel 'gaussian_gaussian.start_for_sigmoid_array_array_ap_fixed_16_6_5_3_0_1u_sigmoid_config29_U0_U' info is :
// blk sig is {{~gaussian_gaussian_inst.start_for_sigmoid_array_array_ap_fixed_16_6_5_3_0_1u_sigmoid_config29_U0_U.if_full_n & gaussian_gaussian_inst.dense_array_ap_ufixed_16u_array_ap_fixed_29_11_5_3_0_1u_config24_U0.ap_start & ~gaussian_gaussian_inst.dense_array_ap_ufixed_16u_array_ap_fixed_29_11_5_3_0_1u_config24_U0.real_start & (trans_in_cnt_19 == trans_out_cnt_19) & ~gaussian_gaussian_inst.start_for_sigmoid_array_array_ap_fixed_16_6_5_3_0_1u_sigmoid_config29_U0_U.if_read} start_FIFO}
                        if ((~start_for_sigmoid_array_array_ap_fixed_16_6_5_3_0_1u_sigmoid_config29_U0_U.if_full_n & dense_array_ap_ufixed_16u_array_ap_fixed_29_11_5_3_0_1u_config24_U0.ap_start & ~dense_array_ap_ufixed_16u_array_ap_fixed_29_11_5_3_0_1u_config24_U0.real_start & (trans_in_cnt_19 == trans_out_cnt_19) & ~start_for_sigmoid_array_array_ap_fixed_16_6_5_3_0_1u_sigmoid_config29_U0_U.if_read)) begin
                            $display("//      Blocked by full output start propagation FIFO 'gaussian_gaussian.start_for_sigmoid_array_array_ap_fixed_16_6_5_3_0_1u_sigmoid_config29_U0_U' read by process 'gaussian_gaussian.sigmoid_array_array_ap_fixed_16_6_5_3_0_1u_sigmoid_config29_U0',");
                        end
                    end
                    endcase
                end
                20 : begin // for proc 'gaussian_gaussian.sigmoid_array_array_ap_fixed_16_6_5_3_0_2u_sigmoid_config26_U0'
                    case(index2)
                    16: begin //  for dep proc 'gaussian_gaussian.dense_array_ap_ufixed_16u_array_ap_fixed_29_11_5_3_0_2u_config18_U0'
// for dep channel 'gaussian_gaussian.layer18_out_U' info is :
// blk sig is {~gaussian_gaussian_inst.sigmoid_array_array_ap_fixed_16_6_5_3_0_2u_sigmoid_config26_U0.layer18_out_blk_n data_FIFO}
                        if ((~sigmoid_array_array_ap_fixed_16_6_5_3_0_2u_sigmoid_config26_U0.layer18_out_blk_n)) begin
                            if (~layer18_out_U.if_empty_n) begin
                                $display("//      Blocked by empty input FIFO 'gaussian_gaussian.layer18_out_U' written by process 'gaussian_gaussian.dense_array_ap_ufixed_16u_array_ap_fixed_29_11_5_3_0_2u_config18_U0'");
                                $fdisplay(fp, "Dependence_Channel_path gaussian_gaussian.layer18_out_U");
                                $fdisplay(fp, "Dependence_Channel_status EMPTY");
                            end
                            else if (~layer18_out_U.if_full_n) begin
                                $display("//      Blocked by full output FIFO 'gaussian_gaussian.layer18_out_U' read by process 'gaussian_gaussian.dense_array_ap_ufixed_16u_array_ap_fixed_29_11_5_3_0_2u_config18_U0'");
                                $fdisplay(fp, "Dependence_Channel_path gaussian_gaussian.layer18_out_U");
                                $fdisplay(fp, "Dependence_Channel_status FULL");
                            end
                        end
// for dep channel 'gaussian_gaussian.start_for_sigmoid_array_array_ap_fixed_16_6_5_3_0_2u_sigmoid_config26_U0_U' info is :
// blk sig is {{~gaussian_gaussian_inst.start_for_sigmoid_array_array_ap_fixed_16_6_5_3_0_2u_sigmoid_config26_U0_U.if_empty_n & gaussian_gaussian_inst.sigmoid_array_array_ap_fixed_16_6_5_3_0_2u_sigmoid_config26_U0.ap_idle & ~gaussian_gaussian_inst.start_for_sigmoid_array_array_ap_fixed_16_6_5_3_0_2u_sigmoid_config26_U0_U.if_write} start_FIFO}
                        if ((~start_for_sigmoid_array_array_ap_fixed_16_6_5_3_0_2u_sigmoid_config26_U0_U.if_empty_n & sigmoid_array_array_ap_fixed_16_6_5_3_0_2u_sigmoid_config26_U0.ap_idle & ~start_for_sigmoid_array_array_ap_fixed_16_6_5_3_0_2u_sigmoid_config26_U0_U.if_write)) begin
                            $display("//      Blocked by missing 'ap_start' from start propagation FIFO 'gaussian_gaussian.start_for_sigmoid_array_array_ap_fixed_16_6_5_3_0_2u_sigmoid_config26_U0_U' written by process 'gaussian_gaussian.dense_array_ap_ufixed_16u_array_ap_fixed_29_11_5_3_0_2u_config18_U0',");
                        end
                    end
                    24: begin //  for dep proc 'gaussian_gaussian.concatenate1d_array_array_array_ap_fixed_16_6_5_3_0_4u_config30_U0'
// for dep channel 'gaussian_gaussian.layer26_out_U' info is :
// blk sig is {~gaussian_gaussian_inst.sigmoid_array_array_ap_fixed_16_6_5_3_0_2u_sigmoid_config26_U0.layer26_out_blk_n data_FIFO}
                        if ((~sigmoid_array_array_ap_fixed_16_6_5_3_0_2u_sigmoid_config26_U0.layer26_out_blk_n)) begin
                            if (~layer26_out_U.if_empty_n) begin
                                $display("//      Blocked by empty input FIFO 'gaussian_gaussian.layer26_out_U' written by process 'gaussian_gaussian.concatenate1d_array_array_array_ap_fixed_16_6_5_3_0_4u_config30_U0'");
                                $fdisplay(fp, "Dependence_Channel_path gaussian_gaussian.layer26_out_U");
                                $fdisplay(fp, "Dependence_Channel_status EMPTY");
                            end
                            else if (~layer26_out_U.if_full_n) begin
                                $display("//      Blocked by full output FIFO 'gaussian_gaussian.layer26_out_U' read by process 'gaussian_gaussian.concatenate1d_array_array_array_ap_fixed_16_6_5_3_0_4u_config30_U0'");
                                $fdisplay(fp, "Dependence_Channel_path gaussian_gaussian.layer26_out_U");
                                $fdisplay(fp, "Dependence_Channel_status FULL");
                            end
                        end
// for dep channel 'gaussian_gaussian.start_for_concatenate1d_array_array_array_ap_fixed_16_6_5_3_0_4u_config30_U0_U' info is :
// blk sig is {{~gaussian_gaussian_inst.start_for_concatenate1d_array_array_array_ap_fixed_16_6_5_3_0_4u_config30_U0_U.if_full_n & gaussian_gaussian_inst.sigmoid_array_array_ap_fixed_16_6_5_3_0_2u_sigmoid_config26_U0.ap_start & ~gaussian_gaussian_inst.sigmoid_array_array_ap_fixed_16_6_5_3_0_2u_sigmoid_config26_U0.real_start & (trans_in_cnt_20 == trans_out_cnt_20) & ~gaussian_gaussian_inst.start_for_concatenate1d_array_array_array_ap_fixed_16_6_5_3_0_4u_config30_U0_U.if_read} start_FIFO}
                        if ((~start_for_concatenate1d_array_array_array_ap_fixed_16_6_5_3_0_4u_config30_U0_U.if_full_n & sigmoid_array_array_ap_fixed_16_6_5_3_0_2u_sigmoid_config26_U0.ap_start & ~sigmoid_array_array_ap_fixed_16_6_5_3_0_2u_sigmoid_config26_U0.real_start & (trans_in_cnt_20 == trans_out_cnt_20) & ~start_for_concatenate1d_array_array_array_ap_fixed_16_6_5_3_0_4u_config30_U0_U.if_read)) begin
                            $display("//      Blocked by full output start propagation FIFO 'gaussian_gaussian.start_for_concatenate1d_array_array_array_ap_fixed_16_6_5_3_0_4u_config30_U0_U' read by process 'gaussian_gaussian.concatenate1d_array_array_array_ap_fixed_16_6_5_3_0_4u_config30_U0',");
                        end
                    end
                    endcase
                end
                21 : begin // for proc 'gaussian_gaussian.softplus_array_array_ap_fixed_16_6_5_3_0_2u_softplus_config27_U0'
                    case(index2)
                    17: begin //  for dep proc 'gaussian_gaussian.dense_array_ap_ufixed_16u_array_ap_fixed_29_11_5_3_0_2u_config20_U0'
// for dep channel 'gaussian_gaussian.layer20_out_U' info is :
// blk sig is {~gaussian_gaussian_inst.softplus_array_array_ap_fixed_16_6_5_3_0_2u_softplus_config27_U0.layer20_out_blk_n data_FIFO}
                        if ((~softplus_array_array_ap_fixed_16_6_5_3_0_2u_softplus_config27_U0.layer20_out_blk_n)) begin
                            if (~layer20_out_U.if_empty_n) begin
                                $display("//      Blocked by empty input FIFO 'gaussian_gaussian.layer20_out_U' written by process 'gaussian_gaussian.dense_array_ap_ufixed_16u_array_ap_fixed_29_11_5_3_0_2u_config20_U0'");
                                $fdisplay(fp, "Dependence_Channel_path gaussian_gaussian.layer20_out_U");
                                $fdisplay(fp, "Dependence_Channel_status EMPTY");
                            end
                            else if (~layer20_out_U.if_full_n) begin
                                $display("//      Blocked by full output FIFO 'gaussian_gaussian.layer20_out_U' read by process 'gaussian_gaussian.dense_array_ap_ufixed_16u_array_ap_fixed_29_11_5_3_0_2u_config20_U0'");
                                $fdisplay(fp, "Dependence_Channel_path gaussian_gaussian.layer20_out_U");
                                $fdisplay(fp, "Dependence_Channel_status FULL");
                            end
                        end
// for dep channel 'gaussian_gaussian.start_for_softplus_array_array_ap_fixed_16_6_5_3_0_2u_softplus_config27_U0_U' info is :
// blk sig is {{~gaussian_gaussian_inst.start_for_softplus_array_array_ap_fixed_16_6_5_3_0_2u_softplus_config27_U0_U.if_empty_n & gaussian_gaussian_inst.softplus_array_array_ap_fixed_16_6_5_3_0_2u_softplus_config27_U0.ap_idle & ~gaussian_gaussian_inst.start_for_softplus_array_array_ap_fixed_16_6_5_3_0_2u_softplus_config27_U0_U.if_write} start_FIFO}
                        if ((~start_for_softplus_array_array_ap_fixed_16_6_5_3_0_2u_softplus_config27_U0_U.if_empty_n & softplus_array_array_ap_fixed_16_6_5_3_0_2u_softplus_config27_U0.ap_idle & ~start_for_softplus_array_array_ap_fixed_16_6_5_3_0_2u_softplus_config27_U0_U.if_write)) begin
                            $display("//      Blocked by missing 'ap_start' from start propagation FIFO 'gaussian_gaussian.start_for_softplus_array_array_ap_fixed_16_6_5_3_0_2u_softplus_config27_U0_U' written by process 'gaussian_gaussian.dense_array_ap_ufixed_16u_array_ap_fixed_29_11_5_3_0_2u_config20_U0',");
                        end
                    end
                    24: begin //  for dep proc 'gaussian_gaussian.concatenate1d_array_array_array_ap_fixed_16_6_5_3_0_4u_config30_U0'
// for dep channel 'gaussian_gaussian.layer27_out_U' info is :
// blk sig is {~gaussian_gaussian_inst.softplus_array_array_ap_fixed_16_6_5_3_0_2u_softplus_config27_U0.layer27_out_blk_n data_FIFO}
                        if ((~softplus_array_array_ap_fixed_16_6_5_3_0_2u_softplus_config27_U0.layer27_out_blk_n)) begin
                            if (~layer27_out_U.if_empty_n) begin
                                $display("//      Blocked by empty input FIFO 'gaussian_gaussian.layer27_out_U' written by process 'gaussian_gaussian.concatenate1d_array_array_array_ap_fixed_16_6_5_3_0_4u_config30_U0'");
                                $fdisplay(fp, "Dependence_Channel_path gaussian_gaussian.layer27_out_U");
                                $fdisplay(fp, "Dependence_Channel_status EMPTY");
                            end
                            else if (~layer27_out_U.if_full_n) begin
                                $display("//      Blocked by full output FIFO 'gaussian_gaussian.layer27_out_U' read by process 'gaussian_gaussian.concatenate1d_array_array_array_ap_fixed_16_6_5_3_0_4u_config30_U0'");
                                $fdisplay(fp, "Dependence_Channel_path gaussian_gaussian.layer27_out_U");
                                $fdisplay(fp, "Dependence_Channel_status FULL");
                            end
                        end
                    end
                    endcase
                end
                22 : begin // for proc 'gaussian_gaussian.tanh_array_ap_fixed_2u_array_ap_fixed_16_6_5_3_0_2u_tanh_config28_U0'
                    case(index2)
                    18: begin //  for dep proc 'gaussian_gaussian.dense_array_ap_ufixed_16u_array_ap_fixed_29_11_5_3_0_2u_config22_U0'
// for dep channel 'gaussian_gaussian.layer22_out_U' info is :
// blk sig is {~gaussian_gaussian_inst.tanh_array_ap_fixed_2u_array_ap_fixed_16_6_5_3_0_2u_tanh_config28_U0.layer22_out_blk_n data_FIFO}
                        if ((~tanh_array_ap_fixed_2u_array_ap_fixed_16_6_5_3_0_2u_tanh_config28_U0.layer22_out_blk_n)) begin
                            if (~layer22_out_U.if_empty_n) begin
                                $display("//      Blocked by empty input FIFO 'gaussian_gaussian.layer22_out_U' written by process 'gaussian_gaussian.dense_array_ap_ufixed_16u_array_ap_fixed_29_11_5_3_0_2u_config22_U0'");
                                $fdisplay(fp, "Dependence_Channel_path gaussian_gaussian.layer22_out_U");
                                $fdisplay(fp, "Dependence_Channel_status EMPTY");
                            end
                            else if (~layer22_out_U.if_full_n) begin
                                $display("//      Blocked by full output FIFO 'gaussian_gaussian.layer22_out_U' read by process 'gaussian_gaussian.dense_array_ap_ufixed_16u_array_ap_fixed_29_11_5_3_0_2u_config22_U0'");
                                $fdisplay(fp, "Dependence_Channel_path gaussian_gaussian.layer22_out_U");
                                $fdisplay(fp, "Dependence_Channel_status FULL");
                            end
                        end
// for dep channel 'gaussian_gaussian.start_for_tanh_array_ap_fixed_2u_array_ap_fixed_16_6_5_3_0_2u_tanh_config28_U0_U' info is :
// blk sig is {{~gaussian_gaussian_inst.start_for_tanh_array_ap_fixed_2u_array_ap_fixed_16_6_5_3_0_2u_tanh_config28_U0_U.if_empty_n & gaussian_gaussian_inst.tanh_array_ap_fixed_2u_array_ap_fixed_16_6_5_3_0_2u_tanh_config28_U0.ap_idle & ~gaussian_gaussian_inst.start_for_tanh_array_ap_fixed_2u_array_ap_fixed_16_6_5_3_0_2u_tanh_config28_U0_U.if_write} start_FIFO}
                        if ((~start_for_tanh_array_ap_fixed_2u_array_ap_fixed_16_6_5_3_0_2u_tanh_config28_U0_U.if_empty_n & tanh_array_ap_fixed_2u_array_ap_fixed_16_6_5_3_0_2u_tanh_config28_U0.ap_idle & ~start_for_tanh_array_ap_fixed_2u_array_ap_fixed_16_6_5_3_0_2u_tanh_config28_U0_U.if_write)) begin
                            $display("//      Blocked by missing 'ap_start' from start propagation FIFO 'gaussian_gaussian.start_for_tanh_array_ap_fixed_2u_array_ap_fixed_16_6_5_3_0_2u_tanh_config28_U0_U' written by process 'gaussian_gaussian.dense_array_ap_ufixed_16u_array_ap_fixed_29_11_5_3_0_2u_config22_U0',");
                        end
                    end
                    25: begin //  for dep proc 'gaussian_gaussian.concatenate1d_array_array_array_ap_fixed_16_6_5_3_0_3u_config31_U0'
// for dep channel 'gaussian_gaussian.layer28_out_U' info is :
// blk sig is {~gaussian_gaussian_inst.tanh_array_ap_fixed_2u_array_ap_fixed_16_6_5_3_0_2u_tanh_config28_U0.layer28_out_blk_n data_FIFO}
                        if ((~tanh_array_ap_fixed_2u_array_ap_fixed_16_6_5_3_0_2u_tanh_config28_U0.layer28_out_blk_n)) begin
                            if (~layer28_out_U.if_empty_n) begin
                                $display("//      Blocked by empty input FIFO 'gaussian_gaussian.layer28_out_U' written by process 'gaussian_gaussian.concatenate1d_array_array_array_ap_fixed_16_6_5_3_0_3u_config31_U0'");
                                $fdisplay(fp, "Dependence_Channel_path gaussian_gaussian.layer28_out_U");
                                $fdisplay(fp, "Dependence_Channel_status EMPTY");
                            end
                            else if (~layer28_out_U.if_full_n) begin
                                $display("//      Blocked by full output FIFO 'gaussian_gaussian.layer28_out_U' read by process 'gaussian_gaussian.concatenate1d_array_array_array_ap_fixed_16_6_5_3_0_3u_config31_U0'");
                                $fdisplay(fp, "Dependence_Channel_path gaussian_gaussian.layer28_out_U");
                                $fdisplay(fp, "Dependence_Channel_status FULL");
                            end
                        end
// for dep channel 'gaussian_gaussian.start_for_concatenate1d_array_array_array_ap_fixed_16_6_5_3_0_3u_config31_U0_U' info is :
// blk sig is {{~gaussian_gaussian_inst.start_for_concatenate1d_array_array_array_ap_fixed_16_6_5_3_0_3u_config31_U0_U.if_full_n & gaussian_gaussian_inst.tanh_array_ap_fixed_2u_array_ap_fixed_16_6_5_3_0_2u_tanh_config28_U0.ap_start & ~gaussian_gaussian_inst.tanh_array_ap_fixed_2u_array_ap_fixed_16_6_5_3_0_2u_tanh_config28_U0.real_start & (trans_in_cnt_21 == trans_out_cnt_21) & ~gaussian_gaussian_inst.start_for_concatenate1d_array_array_array_ap_fixed_16_6_5_3_0_3u_config31_U0_U.if_read} start_FIFO}
                        if ((~start_for_concatenate1d_array_array_array_ap_fixed_16_6_5_3_0_3u_config31_U0_U.if_full_n & tanh_array_ap_fixed_2u_array_ap_fixed_16_6_5_3_0_2u_tanh_config28_U0.ap_start & ~tanh_array_ap_fixed_2u_array_ap_fixed_16_6_5_3_0_2u_tanh_config28_U0.real_start & (trans_in_cnt_21 == trans_out_cnt_21) & ~start_for_concatenate1d_array_array_array_ap_fixed_16_6_5_3_0_3u_config31_U0_U.if_read)) begin
                            $display("//      Blocked by full output start propagation FIFO 'gaussian_gaussian.start_for_concatenate1d_array_array_array_ap_fixed_16_6_5_3_0_3u_config31_U0_U' read by process 'gaussian_gaussian.concatenate1d_array_array_array_ap_fixed_16_6_5_3_0_3u_config31_U0',");
                        end
                    end
                    endcase
                end
                23 : begin // for proc 'gaussian_gaussian.sigmoid_array_array_ap_fixed_16_6_5_3_0_1u_sigmoid_config29_U0'
                    case(index2)
                    19: begin //  for dep proc 'gaussian_gaussian.dense_array_ap_ufixed_16u_array_ap_fixed_29_11_5_3_0_1u_config24_U0'
// for dep channel 'gaussian_gaussian.layer24_out_U' info is :
// blk sig is {~gaussian_gaussian_inst.sigmoid_array_array_ap_fixed_16_6_5_3_0_1u_sigmoid_config29_U0.layer24_out_blk_n data_FIFO}
                        if ((~sigmoid_array_array_ap_fixed_16_6_5_3_0_1u_sigmoid_config29_U0.layer24_out_blk_n)) begin
                            if (~layer24_out_U.if_empty_n) begin
                                $display("//      Blocked by empty input FIFO 'gaussian_gaussian.layer24_out_U' written by process 'gaussian_gaussian.dense_array_ap_ufixed_16u_array_ap_fixed_29_11_5_3_0_1u_config24_U0'");
                                $fdisplay(fp, "Dependence_Channel_path gaussian_gaussian.layer24_out_U");
                                $fdisplay(fp, "Dependence_Channel_status EMPTY");
                            end
                            else if (~layer24_out_U.if_full_n) begin
                                $display("//      Blocked by full output FIFO 'gaussian_gaussian.layer24_out_U' read by process 'gaussian_gaussian.dense_array_ap_ufixed_16u_array_ap_fixed_29_11_5_3_0_1u_config24_U0'");
                                $fdisplay(fp, "Dependence_Channel_path gaussian_gaussian.layer24_out_U");
                                $fdisplay(fp, "Dependence_Channel_status FULL");
                            end
                        end
// for dep channel 'gaussian_gaussian.start_for_sigmoid_array_array_ap_fixed_16_6_5_3_0_1u_sigmoid_config29_U0_U' info is :
// blk sig is {{~gaussian_gaussian_inst.start_for_sigmoid_array_array_ap_fixed_16_6_5_3_0_1u_sigmoid_config29_U0_U.if_empty_n & gaussian_gaussian_inst.sigmoid_array_array_ap_fixed_16_6_5_3_0_1u_sigmoid_config29_U0.ap_idle & ~gaussian_gaussian_inst.start_for_sigmoid_array_array_ap_fixed_16_6_5_3_0_1u_sigmoid_config29_U0_U.if_write} start_FIFO}
                        if ((~start_for_sigmoid_array_array_ap_fixed_16_6_5_3_0_1u_sigmoid_config29_U0_U.if_empty_n & sigmoid_array_array_ap_fixed_16_6_5_3_0_1u_sigmoid_config29_U0.ap_idle & ~start_for_sigmoid_array_array_ap_fixed_16_6_5_3_0_1u_sigmoid_config29_U0_U.if_write)) begin
                            $display("//      Blocked by missing 'ap_start' from start propagation FIFO 'gaussian_gaussian.start_for_sigmoid_array_array_ap_fixed_16_6_5_3_0_1u_sigmoid_config29_U0_U' written by process 'gaussian_gaussian.dense_array_ap_ufixed_16u_array_ap_fixed_29_11_5_3_0_1u_config24_U0',");
                        end
                    end
                    25: begin //  for dep proc 'gaussian_gaussian.concatenate1d_array_array_array_ap_fixed_16_6_5_3_0_3u_config31_U0'
// for dep channel 'gaussian_gaussian.layer29_out_U' info is :
// blk sig is {~gaussian_gaussian_inst.sigmoid_array_array_ap_fixed_16_6_5_3_0_1u_sigmoid_config29_U0.layer29_out_blk_n data_FIFO}
                        if ((~sigmoid_array_array_ap_fixed_16_6_5_3_0_1u_sigmoid_config29_U0.layer29_out_blk_n)) begin
                            if (~layer29_out_U.if_empty_n) begin
                                $display("//      Blocked by empty input FIFO 'gaussian_gaussian.layer29_out_U' written by process 'gaussian_gaussian.concatenate1d_array_array_array_ap_fixed_16_6_5_3_0_3u_config31_U0'");
                                $fdisplay(fp, "Dependence_Channel_path gaussian_gaussian.layer29_out_U");
                                $fdisplay(fp, "Dependence_Channel_status EMPTY");
                            end
                            else if (~layer29_out_U.if_full_n) begin
                                $display("//      Blocked by full output FIFO 'gaussian_gaussian.layer29_out_U' read by process 'gaussian_gaussian.concatenate1d_array_array_array_ap_fixed_16_6_5_3_0_3u_config31_U0'");
                                $fdisplay(fp, "Dependence_Channel_path gaussian_gaussian.layer29_out_U");
                                $fdisplay(fp, "Dependence_Channel_status FULL");
                            end
                        end
                    end
                    endcase
                end
                24 : begin // for proc 'gaussian_gaussian.concatenate1d_array_array_array_ap_fixed_16_6_5_3_0_4u_config30_U0'
                    case(index2)
                    20: begin //  for dep proc 'gaussian_gaussian.sigmoid_array_array_ap_fixed_16_6_5_3_0_2u_sigmoid_config26_U0'
// for dep channel 'gaussian_gaussian.layer26_out_U' info is :
// blk sig is {~gaussian_gaussian_inst.concatenate1d_array_array_array_ap_fixed_16_6_5_3_0_4u_config30_U0.layer26_out_blk_n data_FIFO}
                        if ((~concatenate1d_array_array_array_ap_fixed_16_6_5_3_0_4u_config30_U0.layer26_out_blk_n)) begin
                            if (~layer26_out_U.if_empty_n) begin
                                $display("//      Blocked by empty input FIFO 'gaussian_gaussian.layer26_out_U' written by process 'gaussian_gaussian.sigmoid_array_array_ap_fixed_16_6_5_3_0_2u_sigmoid_config26_U0'");
                                $fdisplay(fp, "Dependence_Channel_path gaussian_gaussian.layer26_out_U");
                                $fdisplay(fp, "Dependence_Channel_status EMPTY");
                            end
                            else if (~layer26_out_U.if_full_n) begin
                                $display("//      Blocked by full output FIFO 'gaussian_gaussian.layer26_out_U' read by process 'gaussian_gaussian.sigmoid_array_array_ap_fixed_16_6_5_3_0_2u_sigmoid_config26_U0'");
                                $fdisplay(fp, "Dependence_Channel_path gaussian_gaussian.layer26_out_U");
                                $fdisplay(fp, "Dependence_Channel_status FULL");
                            end
                        end
// for dep channel 'gaussian_gaussian.start_for_concatenate1d_array_array_array_ap_fixed_16_6_5_3_0_4u_config30_U0_U' info is :
// blk sig is {{~gaussian_gaussian_inst.start_for_concatenate1d_array_array_array_ap_fixed_16_6_5_3_0_4u_config30_U0_U.if_empty_n & gaussian_gaussian_inst.concatenate1d_array_array_array_ap_fixed_16_6_5_3_0_4u_config30_U0.ap_idle & ~gaussian_gaussian_inst.start_for_concatenate1d_array_array_array_ap_fixed_16_6_5_3_0_4u_config30_U0_U.if_write} start_FIFO}
                        if ((~start_for_concatenate1d_array_array_array_ap_fixed_16_6_5_3_0_4u_config30_U0_U.if_empty_n & concatenate1d_array_array_array_ap_fixed_16_6_5_3_0_4u_config30_U0.ap_idle & ~start_for_concatenate1d_array_array_array_ap_fixed_16_6_5_3_0_4u_config30_U0_U.if_write)) begin
                            $display("//      Blocked by missing 'ap_start' from start propagation FIFO 'gaussian_gaussian.start_for_concatenate1d_array_array_array_ap_fixed_16_6_5_3_0_4u_config30_U0_U' written by process 'gaussian_gaussian.sigmoid_array_array_ap_fixed_16_6_5_3_0_2u_sigmoid_config26_U0',");
                        end
                    end
                    21: begin //  for dep proc 'gaussian_gaussian.softplus_array_array_ap_fixed_16_6_5_3_0_2u_softplus_config27_U0'
// for dep channel 'gaussian_gaussian.layer27_out_U' info is :
// blk sig is {~gaussian_gaussian_inst.concatenate1d_array_array_array_ap_fixed_16_6_5_3_0_4u_config30_U0.layer27_out_blk_n data_FIFO}
                        if ((~concatenate1d_array_array_array_ap_fixed_16_6_5_3_0_4u_config30_U0.layer27_out_blk_n)) begin
                            if (~layer27_out_U.if_empty_n) begin
                                $display("//      Blocked by empty input FIFO 'gaussian_gaussian.layer27_out_U' written by process 'gaussian_gaussian.softplus_array_array_ap_fixed_16_6_5_3_0_2u_softplus_config27_U0'");
                                $fdisplay(fp, "Dependence_Channel_path gaussian_gaussian.layer27_out_U");
                                $fdisplay(fp, "Dependence_Channel_status EMPTY");
                            end
                            else if (~layer27_out_U.if_full_n) begin
                                $display("//      Blocked by full output FIFO 'gaussian_gaussian.layer27_out_U' read by process 'gaussian_gaussian.softplus_array_array_ap_fixed_16_6_5_3_0_2u_softplus_config27_U0'");
                                $fdisplay(fp, "Dependence_Channel_path gaussian_gaussian.layer27_out_U");
                                $fdisplay(fp, "Dependence_Channel_status FULL");
                            end
                        end
                    end
                    26: begin //  for dep proc 'gaussian_gaussian.concatenate1d_array_array_array_ap_fixed_16_6_5_3_0_7u_config32_U0'
// for dep channel 'gaussian_gaussian.layer30_out_U' info is :
// blk sig is {~gaussian_gaussian_inst.concatenate1d_array_array_array_ap_fixed_16_6_5_3_0_4u_config30_U0.layer30_out_blk_n data_FIFO}
                        if ((~concatenate1d_array_array_array_ap_fixed_16_6_5_3_0_4u_config30_U0.layer30_out_blk_n)) begin
                            if (~layer30_out_U.if_empty_n) begin
                                $display("//      Blocked by empty input FIFO 'gaussian_gaussian.layer30_out_U' written by process 'gaussian_gaussian.concatenate1d_array_array_array_ap_fixed_16_6_5_3_0_7u_config32_U0'");
                                $fdisplay(fp, "Dependence_Channel_path gaussian_gaussian.layer30_out_U");
                                $fdisplay(fp, "Dependence_Channel_status EMPTY");
                            end
                            else if (~layer30_out_U.if_full_n) begin
                                $display("//      Blocked by full output FIFO 'gaussian_gaussian.layer30_out_U' read by process 'gaussian_gaussian.concatenate1d_array_array_array_ap_fixed_16_6_5_3_0_7u_config32_U0'");
                                $fdisplay(fp, "Dependence_Channel_path gaussian_gaussian.layer30_out_U");
                                $fdisplay(fp, "Dependence_Channel_status FULL");
                            end
                        end
// for dep channel 'gaussian_gaussian.start_for_concatenate1d_array_array_array_ap_fixed_16_6_5_3_0_7u_config32_U0_U' info is :
// blk sig is {{~gaussian_gaussian_inst.start_for_concatenate1d_array_array_array_ap_fixed_16_6_5_3_0_7u_config32_U0_U.if_full_n & gaussian_gaussian_inst.concatenate1d_array_array_array_ap_fixed_16_6_5_3_0_4u_config30_U0.ap_start & ~gaussian_gaussian_inst.concatenate1d_array_array_array_ap_fixed_16_6_5_3_0_4u_config30_U0.real_start & (trans_in_cnt_22 == trans_out_cnt_22) & ~gaussian_gaussian_inst.start_for_concatenate1d_array_array_array_ap_fixed_16_6_5_3_0_7u_config32_U0_U.if_read} start_FIFO}
                        if ((~start_for_concatenate1d_array_array_array_ap_fixed_16_6_5_3_0_7u_config32_U0_U.if_full_n & concatenate1d_array_array_array_ap_fixed_16_6_5_3_0_4u_config30_U0.ap_start & ~concatenate1d_array_array_array_ap_fixed_16_6_5_3_0_4u_config30_U0.real_start & (trans_in_cnt_22 == trans_out_cnt_22) & ~start_for_concatenate1d_array_array_array_ap_fixed_16_6_5_3_0_7u_config32_U0_U.if_read)) begin
                            $display("//      Blocked by full output start propagation FIFO 'gaussian_gaussian.start_for_concatenate1d_array_array_array_ap_fixed_16_6_5_3_0_7u_config32_U0_U' read by process 'gaussian_gaussian.concatenate1d_array_array_array_ap_fixed_16_6_5_3_0_7u_config32_U0',");
                        end
                    end
                    endcase
                end
                25 : begin // for proc 'gaussian_gaussian.concatenate1d_array_array_array_ap_fixed_16_6_5_3_0_3u_config31_U0'
                    case(index2)
                    22: begin //  for dep proc 'gaussian_gaussian.tanh_array_ap_fixed_2u_array_ap_fixed_16_6_5_3_0_2u_tanh_config28_U0'
// for dep channel 'gaussian_gaussian.layer28_out_U' info is :
// blk sig is {~gaussian_gaussian_inst.concatenate1d_array_array_array_ap_fixed_16_6_5_3_0_3u_config31_U0.layer28_out_blk_n data_FIFO}
                        if ((~concatenate1d_array_array_array_ap_fixed_16_6_5_3_0_3u_config31_U0.layer28_out_blk_n)) begin
                            if (~layer28_out_U.if_empty_n) begin
                                $display("//      Blocked by empty input FIFO 'gaussian_gaussian.layer28_out_U' written by process 'gaussian_gaussian.tanh_array_ap_fixed_2u_array_ap_fixed_16_6_5_3_0_2u_tanh_config28_U0'");
                                $fdisplay(fp, "Dependence_Channel_path gaussian_gaussian.layer28_out_U");
                                $fdisplay(fp, "Dependence_Channel_status EMPTY");
                            end
                            else if (~layer28_out_U.if_full_n) begin
                                $display("//      Blocked by full output FIFO 'gaussian_gaussian.layer28_out_U' read by process 'gaussian_gaussian.tanh_array_ap_fixed_2u_array_ap_fixed_16_6_5_3_0_2u_tanh_config28_U0'");
                                $fdisplay(fp, "Dependence_Channel_path gaussian_gaussian.layer28_out_U");
                                $fdisplay(fp, "Dependence_Channel_status FULL");
                            end
                        end
// for dep channel 'gaussian_gaussian.start_for_concatenate1d_array_array_array_ap_fixed_16_6_5_3_0_3u_config31_U0_U' info is :
// blk sig is {{~gaussian_gaussian_inst.start_for_concatenate1d_array_array_array_ap_fixed_16_6_5_3_0_3u_config31_U0_U.if_empty_n & gaussian_gaussian_inst.concatenate1d_array_array_array_ap_fixed_16_6_5_3_0_3u_config31_U0.ap_idle & ~gaussian_gaussian_inst.start_for_concatenate1d_array_array_array_ap_fixed_16_6_5_3_0_3u_config31_U0_U.if_write} start_FIFO}
                        if ((~start_for_concatenate1d_array_array_array_ap_fixed_16_6_5_3_0_3u_config31_U0_U.if_empty_n & concatenate1d_array_array_array_ap_fixed_16_6_5_3_0_3u_config31_U0.ap_idle & ~start_for_concatenate1d_array_array_array_ap_fixed_16_6_5_3_0_3u_config31_U0_U.if_write)) begin
                            $display("//      Blocked by missing 'ap_start' from start propagation FIFO 'gaussian_gaussian.start_for_concatenate1d_array_array_array_ap_fixed_16_6_5_3_0_3u_config31_U0_U' written by process 'gaussian_gaussian.tanh_array_ap_fixed_2u_array_ap_fixed_16_6_5_3_0_2u_tanh_config28_U0',");
                        end
                    end
                    23: begin //  for dep proc 'gaussian_gaussian.sigmoid_array_array_ap_fixed_16_6_5_3_0_1u_sigmoid_config29_U0'
// for dep channel 'gaussian_gaussian.layer29_out_U' info is :
// blk sig is {~gaussian_gaussian_inst.concatenate1d_array_array_array_ap_fixed_16_6_5_3_0_3u_config31_U0.layer29_out_blk_n data_FIFO}
                        if ((~concatenate1d_array_array_array_ap_fixed_16_6_5_3_0_3u_config31_U0.layer29_out_blk_n)) begin
                            if (~layer29_out_U.if_empty_n) begin
                                $display("//      Blocked by empty input FIFO 'gaussian_gaussian.layer29_out_U' written by process 'gaussian_gaussian.sigmoid_array_array_ap_fixed_16_6_5_3_0_1u_sigmoid_config29_U0'");
                                $fdisplay(fp, "Dependence_Channel_path gaussian_gaussian.layer29_out_U");
                                $fdisplay(fp, "Dependence_Channel_status EMPTY");
                            end
                            else if (~layer29_out_U.if_full_n) begin
                                $display("//      Blocked by full output FIFO 'gaussian_gaussian.layer29_out_U' read by process 'gaussian_gaussian.sigmoid_array_array_ap_fixed_16_6_5_3_0_1u_sigmoid_config29_U0'");
                                $fdisplay(fp, "Dependence_Channel_path gaussian_gaussian.layer29_out_U");
                                $fdisplay(fp, "Dependence_Channel_status FULL");
                            end
                        end
                    end
                    26: begin //  for dep proc 'gaussian_gaussian.concatenate1d_array_array_array_ap_fixed_16_6_5_3_0_7u_config32_U0'
// for dep channel 'gaussian_gaussian.layer31_out_U' info is :
// blk sig is {~gaussian_gaussian_inst.concatenate1d_array_array_array_ap_fixed_16_6_5_3_0_3u_config31_U0.layer31_out_blk_n data_FIFO}
                        if ((~concatenate1d_array_array_array_ap_fixed_16_6_5_3_0_3u_config31_U0.layer31_out_blk_n)) begin
                            if (~layer31_out_U.if_empty_n) begin
                                $display("//      Blocked by empty input FIFO 'gaussian_gaussian.layer31_out_U' written by process 'gaussian_gaussian.concatenate1d_array_array_array_ap_fixed_16_6_5_3_0_7u_config32_U0'");
                                $fdisplay(fp, "Dependence_Channel_path gaussian_gaussian.layer31_out_U");
                                $fdisplay(fp, "Dependence_Channel_status EMPTY");
                            end
                            else if (~layer31_out_U.if_full_n) begin
                                $display("//      Blocked by full output FIFO 'gaussian_gaussian.layer31_out_U' read by process 'gaussian_gaussian.concatenate1d_array_array_array_ap_fixed_16_6_5_3_0_7u_config32_U0'");
                                $fdisplay(fp, "Dependence_Channel_path gaussian_gaussian.layer31_out_U");
                                $fdisplay(fp, "Dependence_Channel_status FULL");
                            end
                        end
                    end
                    endcase
                end
                26 : begin // for proc 'gaussian_gaussian.concatenate1d_array_array_array_ap_fixed_16_6_5_3_0_7u_config32_U0'
                    case(index2)
                    24: begin //  for dep proc 'gaussian_gaussian.concatenate1d_array_array_array_ap_fixed_16_6_5_3_0_4u_config30_U0'
// for dep channel 'gaussian_gaussian.layer30_out_U' info is :
// blk sig is {~gaussian_gaussian_inst.concatenate1d_array_array_array_ap_fixed_16_6_5_3_0_7u_config32_U0.layer30_out_blk_n data_FIFO}
                        if ((~concatenate1d_array_array_array_ap_fixed_16_6_5_3_0_7u_config32_U0.layer30_out_blk_n)) begin
                            if (~layer30_out_U.if_empty_n) begin
                                $display("//      Blocked by empty input FIFO 'gaussian_gaussian.layer30_out_U' written by process 'gaussian_gaussian.concatenate1d_array_array_array_ap_fixed_16_6_5_3_0_4u_config30_U0'");
                                $fdisplay(fp, "Dependence_Channel_path gaussian_gaussian.layer30_out_U");
                                $fdisplay(fp, "Dependence_Channel_status EMPTY");
                            end
                            else if (~layer30_out_U.if_full_n) begin
                                $display("//      Blocked by full output FIFO 'gaussian_gaussian.layer30_out_U' read by process 'gaussian_gaussian.concatenate1d_array_array_array_ap_fixed_16_6_5_3_0_4u_config30_U0'");
                                $fdisplay(fp, "Dependence_Channel_path gaussian_gaussian.layer30_out_U");
                                $fdisplay(fp, "Dependence_Channel_status FULL");
                            end
                        end
// for dep channel 'gaussian_gaussian.start_for_concatenate1d_array_array_array_ap_fixed_16_6_5_3_0_7u_config32_U0_U' info is :
// blk sig is {{~gaussian_gaussian_inst.start_for_concatenate1d_array_array_array_ap_fixed_16_6_5_3_0_7u_config32_U0_U.if_empty_n & gaussian_gaussian_inst.concatenate1d_array_array_array_ap_fixed_16_6_5_3_0_7u_config32_U0.ap_idle & ~gaussian_gaussian_inst.start_for_concatenate1d_array_array_array_ap_fixed_16_6_5_3_0_7u_config32_U0_U.if_write} start_FIFO}
                        if ((~start_for_concatenate1d_array_array_array_ap_fixed_16_6_5_3_0_7u_config32_U0_U.if_empty_n & concatenate1d_array_array_array_ap_fixed_16_6_5_3_0_7u_config32_U0.ap_idle & ~start_for_concatenate1d_array_array_array_ap_fixed_16_6_5_3_0_7u_config32_U0_U.if_write)) begin
                            $display("//      Blocked by missing 'ap_start' from start propagation FIFO 'gaussian_gaussian.start_for_concatenate1d_array_array_array_ap_fixed_16_6_5_3_0_7u_config32_U0_U' written by process 'gaussian_gaussian.concatenate1d_array_array_array_ap_fixed_16_6_5_3_0_4u_config30_U0',");
                        end
                    end
                    25: begin //  for dep proc 'gaussian_gaussian.concatenate1d_array_array_array_ap_fixed_16_6_5_3_0_3u_config31_U0'
// for dep channel 'gaussian_gaussian.layer31_out_U' info is :
// blk sig is {~gaussian_gaussian_inst.concatenate1d_array_array_array_ap_fixed_16_6_5_3_0_7u_config32_U0.layer31_out_blk_n data_FIFO}
                        if ((~concatenate1d_array_array_array_ap_fixed_16_6_5_3_0_7u_config32_U0.layer31_out_blk_n)) begin
                            if (~layer31_out_U.if_empty_n) begin
                                $display("//      Blocked by empty input FIFO 'gaussian_gaussian.layer31_out_U' written by process 'gaussian_gaussian.concatenate1d_array_array_array_ap_fixed_16_6_5_3_0_3u_config31_U0'");
                                $fdisplay(fp, "Dependence_Channel_path gaussian_gaussian.layer31_out_U");
                                $fdisplay(fp, "Dependence_Channel_status EMPTY");
                            end
                            else if (~layer31_out_U.if_full_n) begin
                                $display("//      Blocked by full output FIFO 'gaussian_gaussian.layer31_out_U' read by process 'gaussian_gaussian.concatenate1d_array_array_array_ap_fixed_16_6_5_3_0_3u_config31_U0'");
                                $fdisplay(fp, "Dependence_Channel_path gaussian_gaussian.layer31_out_U");
                                $fdisplay(fp, "Dependence_Channel_status FULL");
                            end
                        end
                    end
                    endcase
                end
            endcase
        end
    endtask

    // report
    initial begin : report_deadlock
        integer cycle_id;
        integer cycle_comp_id;
        integer record_time;
        wait (dl_reset == 1);
        cycle_id = 1;
        record_time = 0;
        while (1) begin
            @ (negedge dl_clock);
            case (CS_fsm)
                ST_DL_DETECTED: begin
                    cycle_comp_id = 2;
                    if (dl_detect_reg != dl_done_reg && stop_report_path == 1'b0) begin
                        if (dl_done_reg == 'b0) begin
                            print_dl_head;
                            record_time = $time;
                        end
                        print_cycle_start(proc_path(origin), cycle_id);
                        cycle_id = cycle_id + 1;
                    end
                    else begin
                        print_dl_end((cycle_id - 1),record_time);
                        @(negedge dl_clock);
                        @(negedge dl_clock);
                        $finish;
                    end
                end
                ST_DL_REPORT: begin
                    if ((|(dl_in_vec)) & ~(|(dl_in_vec & origin_reg)) & ~(|(reported_proc & dl_in_vec))) begin
                        print_cycle_chan_comp(dl_in_vec_reg, dl_in_vec);
                        print_cycle_proc_comp(proc_path(dl_in_vec), cycle_comp_id);
                        cycle_comp_id = cycle_comp_id + 1;
                    end
                    else begin
                        print_cycle_chan_comp(dl_in_vec_reg, dl_in_vec);
                    end
                end
            endcase
        end
    end
 
